#! /bin/bash
python3 bl_generate_tmuxp.py && tmuxp load run_all.yaml