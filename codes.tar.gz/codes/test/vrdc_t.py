import os, sys
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from log_util.logger import Logger
from models.policy import Policy
from models.value import Value
from parameter.private_config import *
from agent.Agent import EnvRemoteArray
from envs.nonstationary_env import NonstationaryEnv
from utils.replay_memory import Memory, MemoryNp, MemoryArray
import gym
import torch
import numpy as np
import random
from utils.torch_utils import to_device
import time
from utils.timer import Timer
from algorithms.vrdc import VrdcLoss
from tqdm import tqdm
from parameter.Parameter import Parameter
from utils.visualize_repre import visualize_repre, visualize_repre_real_param, visualize_repre_filtered
USE_TQDM = False
"""
docker run --rm -it --shm-size 50gb -v $PWD:/root/workspace sanluosizhou/selfdl:latest -c "export CUDA_VISIBLE_DEVICES=1 && python /root/workspace/test/vrdc_t.py"
docker run --rm -it --shm-size 50gb -v /home/luofm/Code/modified_policy_adapatation:/root/policy_adaptation -p 6006:6006 sanluosizhou/selfdl:latest -c "sleep 25 && cd /root/policy_adaptation && tensorboard --logdir=./log_file"
"""


class VRDC_t:
    def __init__(self, task_name, seed=None, load_pretrain=False, model_dir=None):
        replay_buffer_dir = os.path.join(get_base_path(), 'log_file', task_name, 'replay_buffer.pkl')
        model_dir = os.path.join(get_base_path(), 'log_file', task_name, 'model') if model_dir is None else os.path.join(get_base_path(), 'log_file', model_dir, 'model')
        self.load_pretrain = load_pretrain
        print(f"load parameter from {os.path.join(get_base_path(), 'log_file', task_name)}")
        parameter = Parameter(config_path=os.path.join(get_base_path(), 'log_file', task_name), debug=True)
        print(parameter)
        parameter.use_true_parameter = False
        parameter.use_vrdc = True
        parameter.rnn_fix_length = 16
        parameter.share_ep = False
        parameter.min_batch_size = 100
        parameter.sac_inner_iter_num = 1
        parameter.ep_dim = 2
        parameter.ep_hidden_size = [256, 128, 128, 64]
        parameter.ep_layer_type = ['fc', 'gru', 'gru', 'fc', 'fc']
        parameter.ep_activations = ['leaky_relu', 'linear', 'linear', 'tanh', 'tanh']
        parameter.max_iter_num = 8000
        parameter.seed = 8 if seed is None else seed
        parameter.sac_mini_batch_size = 256
        weight_decay = 0.0
        self.use_sas = False
        self.add_noise = False
        self.noise_ampti = 0.1
        self.parameter = parameter

        self.logger = Logger(parameter=parameter)
        print('model output path is {}'.format(self.logger.model_output_dir))
        # self.logger.set_tb_x_label('TotalInteraction')
        self.timer = Timer()

        self.policy_config = Policy.make_config_from_param(self.parameter)
        # self.policy_config['use_sas'] = self.use_sas
        self.value_config = Value.make_config_from_param(self.parameter)
        self.env = NonstationaryEnv(gym.make(self.parameter.env_name), log_scale_limit=ENV_DEFAULT_CHANGE,
                                    rand_params=self.parameter.varying_params)
        self.global_seed(np.random, random, self.env, seed=self.parameter.seed)
        torch.manual_seed(seed=self.parameter.seed)
        self.env_tasks = self.env.sample_tasks(self.parameter.task_num)
        assert not self.parameter.use_true_parameter, "cannot use true parameter, this program is used to test rnn + vrdc"
        self.training_agent = EnvRemoteArray(parameter=self.parameter, env_name=self.parameter.env_name,
                                             worker_num=1, seed=self.parameter.seed,
                                             deterministic=False, use_remote=False, policy_type=Policy,
                                             history_len=self.parameter.history_length, env_decoration=NonstationaryEnv,
                                             env_tasks=self.env_tasks,
                                             use_true_parameter=self.parameter.use_true_parameter,
                                             non_stationary=False)
        self.obs_dim = self.training_agent.obs_dim
        self.act_dim = self.training_agent.act_dim
        print(f'observation dim is {self.obs_dim}, action dim is {self.act_dim}')
        self.policy = Policy(self.training_agent.obs_dim, self.training_agent.act_dim, **self.policy_config)
        self.value1 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.value2 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.target_value1 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.target_value2 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.tau = self.parameter.sac_tau
        self.target_entropy = - self.parameter.target_entropy_ratio * self.act_dim
        self.replay_buffer = MemoryArray()
        self.logger(f"slice num is {self.parameter.rnn_slice_num}")
        # self.replay_buffer.set_max_size(self.parameter.sac_replay_size)
        self.replay_buffer.load_from_disk(replay_buffer_dir)
        self.replay_buffer.rnn_slice_length = self.parameter.rnn_slice_num
        if self.replay_buffer.fix_length == 0:
            self.logger(f'fix length of the replay buffer is 0!!! stack zeros to it')
            self.replay_buffer.stack_zeros(self.parameter.rnn_fix_length)
        else:
            assert self.replay_buffer.fix_length == self.parameter.rnn_fix_length
        self.replay_buffer.fix_length = self.parameter.rnn_fix_length

        self.env_param_dict = self.make_task_to_env_para(self.replay_buffer)
        # self.replay_buffer_train, self.replay_buffer_validate = self.replay_buffer.split_buffer(self.replay_buffer, 0.5)
        # self.replay_buffer_train, self.replay_buffer_validate = self.replay_buffer, self.replay_buffer
        self.replay_buffer_train, self.replay_buffer_validate = self.replay_buffer.split_buffer(0.7)

        # self.replay_buffer = self.replay_buffer_train
        self.logger(f"load replay buffer from {replay_buffer_dir}, "
                    f"replaybuffer size: {self.replay_buffer.size},")# state dim in replaybuffer: "
                    # `f"{np.shape(self.replay_buffer.memory_buffer[0][0].state)}, action dim is : {np.shape(self.replay_buffer.memory_buffer[0][0].action)}")
        print(f"size of training replaybuffer: {self.replay_buffer_train.size},"
              f" size of validating replaybuffer: {self.replay_buffer_validate.size},"
              f" length of training replaybuffer: {len(self.replay_buffer_train)},"
              f" length of validating replaybuffer: {len(self.replay_buffer_validate)}")
        self.policy_parameter = [*self.policy.parameters(True)]
        self.policy_optimizer = torch.optim.Adam(self.policy_parameter, lr=self.parameter.learning_rate,
                                                 weight_decay=weight_decay)
        self.value_parameter = [*self.value1.parameters(True)] + [*self.value2.parameters(True)]
        self.value_optimizer = torch.optim.Adam(self.value_parameter,
                                                lr=self.parameter.value_learning_rate)
        self.device = torch.device('cuda', index=0) if torch.cuda.is_available() else torch.device('cpu')
        self.logger.log(f"torch device is {self.device}")
        self.log_sac_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                         ) * np.log(self.parameter.sac_alpha)).to(self.device).requires_grad_(True)
        self.alpha_optimizer = torch.optim.Adam([self.log_sac_alpha], lr=1e-2)
        self.log_consis_w_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                                 ) * np.log(100.0)).to(self.device).requires_grad_(
            True)
        self.log_diverse_w_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                                 ) * np.log(1.0)).to(self.device).requires_grad_(
            True)
        self.w_optimizer = torch.optim.SGD([self.log_consis_w_alpha, self.log_diverse_w_alpha], lr=1e-1)
        self.vrdc_loss = VrdcLoss(target_consistency_metric=-3.5)
        to_device(self.device, self.policy, self.value1, self.value2, self.target_value1, self.target_value2)
        self.logger.log(f'size of parameter of policy: {len(self.policy_parameter)}, '
                        f'size of parameter of value: {len(self.value_parameter)}')
        self.logger.log(f'total env para: {self.env_param_dict}')
        self.logger(f'{self.parameter}')
        self.all_repre = None
        self.all_valids = None
        self.all_repre_validate = None
        self.all_valids_validate = None
        self.all_repre_target = None
        self.all_valids_target = None
        self.all_tasks = None
        self.all_tasks_validate = None
        self.log_w_max = 3.0
        if self.load_pretrain:
            self.load(model_dir)

    def make_task_to_env_para(self, replay_buffer):
        all_trasitions = replay_buffer.sample_transitions()
        print('replay buffer size: ', len(all_trasitions), replay_buffer.size, len(replay_buffer),
              len(all_trasitions.state), len(all_trasitions.task),
              len(all_trasitions.env_param))
        task = all_trasitions.task
        env_param = all_trasitions.env_param
        env_param_dict = {}
        for _task, _env_param in zip(task, env_param):
            if _task[0] not in env_param_dict:
                env_param_dict[_task[0]] = list(_env_param)
        print('Analysis done!!!!')
        return env_param_dict

    @staticmethod
    def global_seed(*args, seed):
        for item in args:
            item.seed(seed)

    def sac_update(self, state, action, next_state, reward, mask, last_action, valid, task,
                   policy_hidden=None, value_hidden1=None, value_hidden2=None, hidden_policy_tmp_ep=None, validate=False):
        """reward, mask should be (-1, 1)"""
        alpha = self.log_sac_alpha.exp()
        if self.parameter.rnn_fix_length is None or self.parameter.rnn_fix_length == 0:
            valid_num = valid.sum()
        else:
            valid_num = valid[..., -1:, :].sum()
        # if not FC_MODE:
        """update critic/value net"""
        # self.timer.register_point('calculating_target_Q', level=3)     # (TIME: 0.011)
        # self.timer.register_end(level=3)
        # self.timer.register_point('current_Q', level=3)     # (TIME: 0.006)
        # current_Q1, _ = self.value1.forward(state, last_action, action, value_hidden1)
        # current_Q2, _ = self.value2.forward(state, last_action, action, value_hidden2)
        # ep_q1, ep_q2 = self.value1.ep_tensor, self.value2.ep_tensor
        # self.timer.register_end(level=3)
        # q1_loss = q2_loss = current_Q1.mean() * 0
        consis_w = self.log_consis_w_alpha.exp()
        deverse_w = self.log_diverse_w_alpha.exp()
        consis_w_loss = None
        diverse_w_loss = None
        batch_task_num = 1
        # if self.parameter.use_vrdc and self.parameter.share_ep:
        #     self.timer.register_point('vrdc_loss', level=5)
        #     # ep, _ = self.policy.get_ep(torch.cat((state, last_action), -1), policy_hidden)
        #     if self.parameter.rnn_fix_length:
        #         ep_q1, ep_q2 = ep_q1[..., -1:, :], ep_q2[..., -1:, :]
        #         task_for_ep, valid_for_ep = task[..., -1:, :], valid[..., -1:, :]
        #     else:
        #         task_for_ep, valid_for_ep = task, valid
        #     vrdc_loss_tensor_q1, consistency_loss_q1, diverse_loss_q1, batch_task_num_q1, consis_w_loss, diverse_w_loss, all_repre, all_valids = self.vrdc_loss.vrdc_loss(ep_q1,
        #                                                                          task_for_ep, valid_for_ep, consis_w, deverse_w, True, True)
        #     vrdc_loss_tensor_q2, consistency_loss_q2, diverse_loss_q2, batch_task_num_q2, all_repre, all_valids = self.vrdc_loss.vrdc_loss(ep_q2,
        #                                                                          task_for_ep, valid_for_ep, consis_w, deverse_w, True, False)
        #     self.all_repre = [item.detach() for item in all_repre]
        #     self.all_valids = [item.detach() for item in all_valids]
        #
        #     batch_task_num = (batch_task_num_q1 + batch_task_num_q2) // 2
        #     if vrdc_loss_tensor_q1 is not None and vrdc_loss_tensor_q2 is not None:
        #         vrdc_loss_tensor = vrdc_loss_tensor_q1 + vrdc_loss_tensor_q2
        #         consistency_loss = consistency_loss_q1 + consistency_loss_q2
        #         diverse_loss = diverse_loss_q1 + diverse_loss_q2
        #         if torch.isnan(consistency_loss).any().item() or torch.isnan(diverse_loss).any().item():
        #             self.logger.log(f'vrdc produce nan: consistency: {consistency_loss.item()}, '
        #                             f'diverse loss: {diverse_loss.item()}')
        #         q1_loss = vrdc_loss_tensor_q1
        #         q2_loss = vrdc_loss_tensor_q2
        #     else:
        #         vrdc_loss_tensor = consistency_loss = diverse_loss = None
        #         self.logger.log(task_for_ep.squeeze())
        #         self.logger.log('vrdc data is invalid...')
        #     self.timer.register_end(level=5)
        # critic_loss = q1_loss + q2_loss
        #
        # self.timer.register_point('value_optimization', level=3)     # (TIME: 0.028)
        # self.value_optimizer.zero_grad()
        # critic_loss.backward()
        # if torch.isnan(critic_loss).any().item():
        #     self.logger.log(f"nan found in critic loss, state: {state.abs().sum()}, "
        #                     f"last action: {last_action.abs().sum()}, "
        #                     f"action: {action.abs().sum()}")
        #     return None
        # value_gradient = torch.nn.utils.clip_grad.clip_grad_norm_(self.value_parameter, 10)
        # # if value_gradient >
        #
        # self.value_optimizer.step()
        # self.timer.register_end(level=3)
        """update policy and alpha"""
        self.timer.register_point('actor_loss', level=3)     # (TIME: 0.012)
        # last_action = torch.cat((last_action, next_state - state), -1)
        # if self.use_sas:
        #     last_state = last_action[..., self.act_dim: ]
        #     state_delta = state - last_state
        #     last_action[..., self.act_dim:] = state_delta
        # else:
        last_state = state
        if self.add_noise and not validate:
            _, _, action_rsample, logprob, _ = self.policy.rsample(last_state + self.noise_ampti * torch.randn_like(last_state),
                                                                   last_action + self.noise_ampti * torch.randn_like(last_action), policy_hidden)
        else:
            _, _, action_rsample, logprob, _ = self.policy.rsample(last_state, last_action, policy_hidden)
        ep = self.policy.ep_tensor
        actor_loss = action_rsample.mean() * 0
        if self.parameter.use_vrdc and not self.parameter.share_ep:
            self.timer.register_point('vrdc_loss', level=5)
            # with torch.no_grad():
            #     vrdc_loss_tensor, consistency_loss, diverse_loss, batch_task_num, all_repre, all_valids = self.vrdc_loss.vrdc_loss(
            #         ep, task, valid, 1.0, 1.0, True)
            #     self.all_repre_target = [item.detach() for item in all_repre]
            #     self.all_valids_target = [item.detach() for item in all_valids]
            # ep, _ = self.policy.get_ep_temp(torch.cat((state, last_action), -1), hidden_policy_tmp_ep)
            if self.parameter.rnn_fix_length:
                ep = ep[..., -1:, :]
            # print(torch.cat((state[0, :, :6], next_state[0, :, :6]), -1))
            vrdc_loss_tensor, consistency_loss, diverse_loss, batch_task_num, consis_w_loss, diverse_w_loss, all_repre, \
                all_valids = self.vrdc_loss.vrdc_loss_timing(ep, task, valid, consis_w, deverse_w, True, True)
            if validate:
                self.all_tasks_validate = self.vrdc_loss.lst_tasks
                self.all_repre_validate = [item.detach() for item in all_repre]
                self.all_valids_validate = [item.detach() for item in all_valids]
            else:
                self.all_repre = [item.detach() for item in all_repre]
                self.all_valids = [item.detach() for item in all_valids]
                self.all_tasks = self.vrdc_loss.lst_tasks
            if vrdc_loss_tensor is not None:
                if torch.isnan(consistency_loss).any().item() or torch.isnan(diverse_loss).any().item():
                    self.logger.log(f'vrdc produce nan: consistency: {consistency_loss.item()}, '
                                    f'diverse loss: {diverse_loss.item()}')
                actor_loss = actor_loss + vrdc_loss_tensor
            else:
                self.logger.log('vrdc data is invalid...')
            self.timer.register_end(level=5)
        self.timer.register_point('policy_optimization', level=3)     # (TIME: 0.026)
        policy_gradient = 0
        if not validate and not self.load_pretrain:
            self.policy_optimizer.zero_grad()
            if torch.isnan(actor_loss).any().item():
                self.logger.log(f"nan found in actor loss, state: {state.abs().sum()}, "
                                f"last action: {last_action.abs().sum()}, "
                                f"action: {action.abs().sum()}")
                return None
            actor_loss.backward()
            policy_gradient = torch.nn.utils.clip_grad.clip_grad_norm_(self.policy_parameter, 10)
            self.policy_optimizer.step()
        self.timer.register_end(level=3)
        w_loss = 0
        if consis_w_loss is not None or diverse_w_loss is not None:
            w_loss = 0 if consis_w_loss is None else consis_w_loss
            w_loss = w_loss if diverse_w_loss is None else diverse_w_loss + w_loss
            # if isinstance(w_loss, torch.Tensor):
            #     self.w_optimizer.zero_grad()
            #     w_loss.backward()
            #     self.w_optimizer.step()
        with torch.no_grad():
            self.log_diverse_w_alpha.clamp_max_(self.log_w_max)
            self.log_consis_w_alpha.clamp_max_(self.log_w_max)
        self.value_function_soft_update()
        if self.parameter.share_ep:
            self.policy.ep.copy_weight_from(self.value1.ep, tau=0.0)
        # if self.parameter.use_vrdc and not self.parameter.share_ep:
        #     self.policy.apply_temp_ep(0.99)
        if self.parameter.rnn_fix_length:
            q_mean1 = 0
            q_mean2 = 0
            logp_pi = logprob.mean().item()

        else:
            q_mean1 = 0
            q_mean2 = 0
            logp_pi = ((logprob * valid).sum() / valid_num).item()
        if self.parameter.use_vrdc:
            vrdc_loss_float = vrdc_loss_tensor.item() if vrdc_loss_tensor is not None else 0
            consistency_loss_float = consistency_loss.item() if consistency_loss is not None else 0
            diverse_loss_float = diverse_loss.item() if diverse_loss is not None else 0
        else:
            vrdc_loss_float = 0.0
            consistency_loss_float = 0.0
            diverse_loss_float = 0.0
            batch_task_num = 0
        # consis_w_item = consis_w.item()
        return dict(
            ActorLoss=actor_loss.item(),
            Alpha=alpha.item(),
            QMean1=q_mean1,
            QMean2=q_mean2,
            Logp=logp_pi,
            PolicyGradient=policy_gradient,
            VRDCLoss=vrdc_loss_float,
            ConsistencyLoss=consistency_loss_float,
            DiverseLoss=diverse_loss_float,
            BatchTaskNum=batch_task_num,
            w_loss=w_loss.item() if isinstance(w_loss, torch.Tensor) else w_loss,
            consistency_w=consis_w.item(),
            diverse_w=deverse_w.item(),
            ValidNum=valid_num.item()
        )

    def sac_update_from_buffer(self, validate=False):
        log = {}
        replay_buffer = self.replay_buffer_validate if validate else self.replay_buffer_train
        for _ in range(self.parameter.update_interval):
            self.timer.register_point('sample_from_replay', level=1)     # (TIME: 0.4)
            if FC_MODE:
                batch = replay_buffer.sample_transitions(self.parameter.sac_mini_batch_size)
            else:
                if self.parameter.rnn_fix_length:
                    batch = replay_buffer.sample_fix_length_sub_trajs(self.parameter.sac_mini_batch_size,
                                                                           self.parameter.rnn_fix_length)
                else:
                    batch, total_size = replay_buffer.sample_trajs(self.parameter.sac_mini_batch_size,
                                                        self.parameter.rnn_sample_max_batch_size)
                # self.logger.log(f'total transition in the trajectories is {total_size}, state shape: {np.array(batch.state).shape}')

            dtype = torch.get_default_dtype()
            device = self.device
            # self.logger(np.array(batch.state), np.array(batch.reward))
            states, next_states, actions, last_action, rewards, masks, valid, task = \
                    map(lambda x: torch.from_numpy(np.array(x)).to(dtype=dtype, device=device),
                    [batch.state, batch.next_state, batch.action, batch.last_action,
                        batch.reward, batch.mask, batch.valid, batch.task])
            if not FC_MODE:
                self.timer.register_point('making_slice', level=3)     # (TIME: 0.14)
                if self.parameter.rnn_fix_length is None or self.parameter.rnn_fix_length == 0:
                    self.timer.register_point('generate_hidden_state', level=4)
                    hidden_policy = self.policy.generate_hidden_state(states, last_action,
                                                                      slice_num=self.parameter.rnn_slice_num)
                    hidden_policy_tmp_ep = self.policy.generate_hidden_state(states, last_action,
                                                                      slice_num=self.parameter.rnn_slice_num, use_tmp_ep=True)
                    hidden_value1 = self.value1.generate_hidden_state(states, last_action, actions,
                                                                      slice_num=self.parameter.rnn_slice_num)
                    hidden_value2 = self.value2.generate_hidden_state(states, last_action, actions,
                                                                      slice_num=self.parameter.rnn_slice_num)
                    self.timer.register_point('Policy.slice_tensor', level=4)
                    states, next_states, actions, last_action, rewards, masks, valid, task = \
                        map(Policy.slice_tensor, [states, next_states, actions, last_action, rewards, masks, valid, task],
                            [self.parameter.rnn_slice_num] * 8)
                    self.timer.register_point('Policy.merge_slice_tensor', level=4)
                    states, next_states, actions, last_action, rewards, masks, valid, task = Policy.merge_slice_tensor(
                        states, next_states, actions, last_action, rewards, masks, valid, task
                    )
                    mask_for_valid = valid.sum(dim=-2, keepdim=True)[..., 0, 0] > 0
                    states, next_states, actions, last_action, rewards, masks, valid, task = map(
                        lambda x: x[mask_for_valid],
                        [states, next_states, actions, last_action, rewards, masks, valid, task]
                    )

                    hidden_policy, hidden_value1, hidden_value2, hidden_policy_tmp_ep = map(
                        Policy.hidden_state_mask,
                        [hidden_policy, hidden_value1, hidden_value2, hidden_policy_tmp_ep],
                        [mask_for_valid, mask_for_valid, mask_for_valid, mask_for_valid]
                    )
                    self.timer.register_end(level=4)
                else:
                    self.timer.register_point('Policy.slice_tensor', level=4)     # (TIME: 0.132)
                    # states, next_states, actions, last_action, rewards, masks, valid, task = \
                    #     map(Policy.slice_tensor_overlap, [states, next_states, actions, last_action, rewards, masks, valid, task],
                    #         [self.parameter.rnn_fix_length] * 8)
                    self.timer.register_end(level=4)
                    # mask_for_valid = valid[..., -1, 0] == 1
                    # states, next_states, actions, last_action, rewards, masks, valid, task = \
                    #     map(lambda x: x[mask_for_valid], [states, next_states, actions, last_action,
                    #                                       rewards, masks, valid, task])
                    self.timer.register_point('generate_hidden_state', level=4)
                    hidden_policy = self.policy.make_init_state(batch_size=states.shape[0], device=states.device)
                    hidden_policy_tmp_ep = self.policy.make_init_state(batch_size=states.shape[0], device=states.device)
                    hidden_value1 = self.value1.make_init_state(batch_size=states.shape[0], device=states.device)
                    hidden_value2 = self.value2.make_init_state(batch_size=states.shape[0], device=states.device)
                    self.timer.register_end(level=4)
                self.timer.register_end(level=3)
            else:
                hidden_policy, hidden_value1, hidden_value2, hidden_policy_tmp_ep = [], [], [], []
            self.timer.register_end(level=1)
            #if custom_additional_reward is not None:
            #    with torch.no_grad():
            #        rewards = rewards + custom_additional_reward(states)
            states, next_states, actions, last_action, rewards, masks, valid, task = map(
                lambda x: x.detach(),
                [states, next_states, actions, last_action, rewards, masks, valid, task]
            )
            hidden_policy, hidden_value1, hidden_value2, hidden_policy_tmp_ep = map(
                Policy.hidden_detach,
                [hidden_policy, hidden_value1, hidden_value2, hidden_policy_tmp_ep]
            )
            with torch.set_grad_enabled(True):
                if FC_MODE:
                    self.timer.register_point('self.sac_update', level=1)
                    res_dict = self.sac_update(states, actions, next_states,
                                               rewards, masks, last_action, valid, task, hidden_policy,
                                               hidden_value1, hidden_value2, hidden_policy_tmp_ep, validate)
                    self.timer.register_end(level=1)
                else:
                    point_num = states.shape[0]
                    total_inds = np.random.permutation(point_num).tolist()
                    iter_batch_size = states.shape[0] // self.parameter.sac_inner_iter_num
                    # self.logger(f'valid traj num: {states.shape[0]}, batch size: {iter_batch_size}')
                    for i in range(self.parameter.sac_inner_iter_num):
                        self.timer.register_point('sample_from_batch', level=1)  # (TIME: 0.003)
                        start = i * iter_batch_size
                        end = min((i + 1) * iter_batch_size, states.shape[0])
                        states_batch, next_states_batch, actions_batch, \
                        last_action_batch, rewards_batch, masks_batch, valid_batch, task_batch = \
                            map(lambda x: x[start: end], [
                                states, next_states, actions, last_action, rewards, masks, valid, task
                            ])
                        data_is_valid = False
                        if self.parameter.rnn_fix_length:
                            if valid_batch[..., -1:, :].sum().item() >= 2:
                                data_is_valid = True
                        elif valid_batch.sum().item() >= 2:
                            data_is_valid = True
                        if not data_is_valid:
                            print('data is not valid!!')
                            continue
                        hidden_policy_batch, hidden_value1_batch, hidden_value2_batch = \
                            map(Policy.hidden_state_slice,
                                [hidden_policy, hidden_value1, hidden_value2],
                                [start] * 3,
                                [end] * 3)
                        self.timer.register_point('self.sac_update', level=1)  # (TIME: 0.091)
                        res_dict = self.sac_update(states_batch, actions_batch, next_states_batch, rewards_batch,
                                                   masks_batch, last_action_batch, valid_batch, task_batch,
                                                   hidden_policy_batch, hidden_value1_batch, hidden_value2_batch, validate=validate)
                        self.timer.register_end(level=1)
                if res_dict is not None:
                    for key in res_dict:
                        if key in log:
                            log[key].append(res_dict[key])
                        else:
                            log[key] = [res_dict[key]]
        return log

    def update(self, step):
        self.policy.train()
        log = self.sac_update_from_buffer()
        if step == 0 or step % 10 == 0:
            self.policy.eval()
            log_validate = self.sac_update_from_buffer(True)
            log_v = {k+'Validate': v for k, v in log_validate.items()}
            log.update(log_v)

        return log

    @staticmethod
    def append_key(d, tail):
        res = {}
        for k, v in d.items():
            res[k+tail] = v
        return res

    def value_function_soft_update(self):
        self.target_value1.copy_weight_from(self.value1, self.tau)
        self.target_value2.copy_weight_from(self.value2, self.tau)

    def run(self):
        total_steps = 0
        if self.replay_buffer.size < self.parameter.start_train_num:
            self.logger(f"init samples!!!")
            self.policy.to(self.device)
            while self.replay_buffer.size < self.parameter.start_train_num:
                mem, log = self.training_agent.sample1step(self.policy,
                                                           self.replay_buffer.size < self.parameter.random_num,
                                                           device=self.device)
                self.replay_buffer.mem_push(mem)
                total_steps += 1
        for iter in range(self.parameter.max_iter_num):
            self.policy.to(torch.device('cpu'))
            self.policy.to(self.device)
            training_start = time.time()
            single_step_iterater = range(self.parameter.min_batch_size) if not USE_TQDM else\
                tqdm(range(self.parameter.min_batch_size))

            for step in single_step_iterater:
                self.timer.register_point('sample1step')
                self.timer.register_end()
                # if step % (self.parameter.update_interval * self.parameter.sac_inner_iter_num) == 0 \
                #         and self.replay_buffer.size > self.parameter.start_train_num and len(self.replay_buffer) > 1:
                self.timer.register_point('self.update')
                update_log = self.update(iter)
                self.timer.register_end()
                self.logger.add_tabular_data(**update_log)
            if iter % 1 == 0:
                fig, fig_mean = visualize_repre(self.all_repre, self.all_valids, os.path.join(self.logger.output_dir, 'visual.png'),
                                                    self.env_param_dict, self.all_tasks )
                fig_real_param = visualize_repre_real_param(self.all_repre, self.all_valids, self.all_tasks, self.env_param_dict)
                if fig:
                    self.logger.tb.add_figure('figs/repre', fig, iter)
                    self.logger.tb.add_figure('figs/repre_mean', fig_mean, iter)
                    self.logger.tb.add_figure('figs/repre_real', fig_real_param, iter)
                fig_validate, fig_mean_validate = visualize_repre(self.all_repre_validate, self.all_valids_validate,
                                                os.path.join(self.logger.output_dir, 'visual_validate.png'),
                                                    self.env_param_dict, self.all_tasks_validate
                                                                  )
                fig_real_param_real = visualize_repre_real_param(self.all_repre_validate, self.all_valids_validate,
                                                            self.all_tasks_validate, self.env_param_dict)
                if fig_validate:
                    self.logger.tb.add_figure('figs/repre_validate', fig_validate, iter)
                    self.logger.tb.add_figure('figs/repre_mean_validate', fig_mean_validate, iter)
                    self.logger.tb.add_figure('figs/repre_real_validate', fig_real_param_real, iter)
                fig_validate_filtered, fig_mean_validate_filtered = visualize_repre_filtered(self.all_repre_validate, self.all_valids_validate,
                                                                  0.8)
                if fig_validate:
                    self.logger.tb.add_figure('figs/repre_validate_filter', fig_validate_filtered, iter)
                    self.logger.tb.add_figure('figs/repre_mean_validate_filter', fig_mean_validate_filtered, iter)
            # fig, fig_mean = visualize_repre(self.all_repre_target, self.all_valids_target, os.path.join(self.logger.output_dir, 'visual_target.png'))
            # if fig:
            #     self.logger.tb.add_figure('figs/repre_target', fig, iter)
            #     self.logger.tb.add_figure('figs/repre_mean_target', fig_mean, iter)

            total_steps += self.parameter.min_batch_size
            if iter % 10 == 0:
                self.save()
            training_end = time.time()
            self.logger.log('start testing...')
            testing_end = time.time()
            self.logger.log_tabular('TotalInteraction', total_steps)
            self.logger.log_tabular('ReplayBufferTrajNum', len(self.replay_buffer))
            self.logger.log_tabular('ReplayBufferSize', self.replay_buffer.size)
            self.logger.log_tabular('TrainingPeriod', training_end - training_start)
            self.logger.log_tabular('TestingPeriod', testing_end - training_end)
            self.logger.add_tabular_data(**self.timer.summary())
            self.logger.dump_tabular()

    def save(self):
        self.policy.save(self.logger.model_output_dir)
        self.value1.save(self.logger.model_output_dir, 0)
        self.value2.save(self.logger.model_output_dir, 1)
        self.target_value1.save(self.logger.model_output_dir, "target0")
        self.target_value2.save(self.logger.model_output_dir, "target1")
        torch.save(self.policy_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'policy_optim.pt'))
        torch.save(self.value_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'value_optim.pt'))
        torch.save(self.alpha_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'alpha_optim.pt'))

    def load(self, model_dir=None):
        if model_dir is None:
            model_dir = self.logger.model_output_dir
        self.policy.load(model_dir, map_location=self.device)
        self.value1.load(model_dir, 0, map_location=self.device)
        self.value2.load(model_dir, 1, map_location=self.device)
        self.target_value1.load(model_dir, "target0", map_location=self.device)
        self.target_value2.load(model_dir, "target1", map_location=self.device)
        self.policy_optimizer.load_state_dict(torch.load(os.path.join(model_dir, 'policy_optim.pt'),
                                                         map_location=self.device))
        self.value_optimizer.load_state_dict(torch.load(os.path.join(model_dir, 'value_optim.pt'),
                                                        map_location=self.device))
        self.alpha_optimizer.load_state_dict(torch.load(os.path.join(model_dir, 'alpha_optim.pt'),
                                                        map_location=self.device))

import argparse
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=EXPERIMENT_TARGET)
    env_name = "Hopper-v2"
    parser.add_argument('--env_name', default=env_name, metavar='G',
                        help='name of the environment to run')

    model_dir = ""
    parser.add_argument('--model_dir', default=model_dir, metavar='G',
                        help='model directory')
    seed = 1
    parser.add_argument('--seed', type=int, default=seed, metavar='N',
                        help='random seed (default: 1)')
    parser.add_argument('--load_pretrain', action='store_true',
                        help='render the environment')
    args = parser.parse_args()

    import ray
    ray.init()
    task_name = args.env_name
    load_pretrain = args.load_pretrain
    model_dir = args.model_dir
    if len(model_dir) == 0:
        model_dir = None
    print('pre-load config file from {}'.format(env_name))
    sac = VRDC_t(task_name, args.seed, args.load_pretrain, model_dir)
    sac.run()
