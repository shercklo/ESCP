#! /bin/bash
sudo rm -rf log_file