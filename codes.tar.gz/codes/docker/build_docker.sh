#! /bin/bash
docker build -t sanluosizhou/selfdl:latest .