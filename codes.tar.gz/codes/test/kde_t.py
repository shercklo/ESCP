import sys,os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.replay_memory import KDE, UniformSample, MCMC_MH, DPP
import random
import numpy as np
import matplotlib.pyplot as plt
import time
if __name__ == '__main__':
    x = np.hstack((np.random.normal(10, 2, 3000), np.random.normal(18, 3, 3000)))
    x = list(x)
    x_dense = list(np.linspace(7, 23, 1000))

    plt.figure(1)
    plt.scatter(x, [0] * len(x))
    kde = KDE()
    kde.feed(x)
    prob = kde.prob(x)
    print([*zip(x, prob)])
    origin_prob = kde.prob(x_dense)
    c = []
    min_prob = np.min(prob)
    print(min_prob)
    # us = UniformSample()
    us = MCMC_MH()
    dpp = DPP()
    # ===================
    for i in range(1000):
        if False:
            while True:
                ind = random.randint(0, len(prob) - 1)
                if random.uniform(0, prob[ind]) < 0.9 * min_prob:
                    break
                # if random.random() > prob[ind]:
                #     break
            c.append(x[ind])
        elif False:
            y = random.sample(x, 600)
            ind = np.argmin(np.abs(np.array(y) - random.uniform(kde.min, kde.max)))
            c.append(y[ind])
    if False:
        time_start = time.time()
        for i in range(20):
            time1 = time.time()
            us.feed(x)
            time2 = time.time()
            inds = us.sample(1000)
            print(f'len(inds): {len(inds)}, time1: {time2 - time1}, time2: {time.time() - time2}')
        for ind in inds:
            c.append(x[ind])
        print(f"time eslapes: {(time.time() - time_start)/20}")
    if True:
        dpp.feed_data(x)
        inds = dpp.sample(1000)
        for ind in inds:
            c.append(x[ind])
    # ===================
    d = [x[random.randint(0, len(prob)-1)] for _ in range(30)]
    kde.feed(c)
    rsample_prob = kde.prob(x_dense)
    kde.feed(d)
    sample_prob = kde.prob(x_dense)
    plt.scatter(c, [1] * len(c))
    plt.scatter(d, [2] * len(d))
    plt.figure(2)
    plt.plot(x_dense, origin_prob, label='origin')
    plt.plot(x_dense, rsample_prob, label='rsample')
    plt.plot(x_dense, sample_prob, label='sample')

    plt.legend()
    plt.show()
    #print(x)
    pass

