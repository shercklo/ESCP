#! /bin/bash
sudo chown -R $(id -u):$(id -g) log_file