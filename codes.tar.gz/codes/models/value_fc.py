from models.rnn_base import RNNBase
import torch
from torch.distributions import Normal
import numpy as np
import os


class Value(torch.nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size, activations, layer_type, logger=None):
        super(Value, self).__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.value = RNNBase(obs_dim + act_dim, 1, hidden_size, activations, layer_type, logger)
        # ep first, up second
        self.module_list = torch.nn.ModuleList(self.value.total_module_list)
        self.min_log_std = -7.0
        self.max_log_std = 2.0

    def meta_forward(self, x):
        return self.value.meta_forward(x, None)[0]

    def forward(self, x, a):
        x = torch.cat((x, a), -1)
        value_out = self.meta_forward(x)
        return value_out

    def save(self, path, index=0):
        self.value.save(os.path.join(path, f'value{index}.pt'))

    def load(self, path, index=0, **kwargs):
        self.value.load(os.path.join(path, f'value{index}.pt'), **kwargs)

    @staticmethod
    def make_config_from_param(parameter):
        return dict(
            hidden_size=parameter.value_hidden_size,
            activations=parameter.value_activations,
            layer_type=parameter.value_layer_type
        )

    def copy_weight_from(self, src, tau):
        """
        I am target net, tau ~~ 1
        if tau = 0, self <--- src_net
        if tau = 1, self <--- self
        """
        self.value.copy_weight_from(src.value, tau)
