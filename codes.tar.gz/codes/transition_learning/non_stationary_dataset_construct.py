import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import matplotlib.pyplot as plt
from log_util.logger import Logger
from models.policy import Policy
from models.value import Value
from parameter.private_config import *
from agent.Agent import EnvRemoteArray
from envs.nonstationary_env import NonstationaryEnv
from utils.replay_memory import Memory, MemoryNp
import gym
import torch
import numpy as np
import random
from utils.torch_utils import to_device
import time
from utils.timer import Timer
from algorithms.vrdc import VrdcLoss
from tqdm import tqdm
from utils.visualize_repre import visualize_repre, visualize_repre_real_param
from parameter.Parameter import Parameter
import argparse

# docker run --rm -it --shm-size 50gb -v $PWD:/root/workspace sanluosizhou/selfdl:latest -c "export CUDA_VISIBLE_DEVICES=1 && cd /root/workspace/ && python transition_learning/non_stationary_dataset_construct.py --seed 1 --task_name Walker2d-v2-use_vrdc-rnn_len_32-enhance_ep-bottle_neck-stop_pg_for_ep-ep_dim_2-1_L2NORM_BOTTLE "
class NsDataConstructor:
    def __init__(self, task_name, seed):
        parameter = Parameter(config_path=os.path.join(get_base_path(), 'log_file', task_name), debug=True)
        parameter.seed = seed
        parameter.num_threads = 8
        parameter.max_iter_num = 200
        model_dir = os.path.join(get_base_path(), 'log_file', task_name, 'model')

        self.logger = Logger(parameter=parameter)
        self.parameter = self.logger.parameter
        self.logger.log(parameter)
        # self.logger.set_tb_x_label('TotalInteraction')
        self.timer = Timer()
        self.policy_config = Policy.make_config_from_param(self.parameter)
        self.value_config = Value.make_config_from_param(self.parameter)
        self.env = NonstationaryEnv(gym.make(self.parameter.env_name), log_scale_limit=ENV_DEFAULT_CHANGE,
                                    rand_params=self.parameter.varying_params)
        self.ood_env = NonstationaryEnv(gym.make(self.parameter.env_name), log_scale_limit=4.0,
                                        rand_params=self.parameter.varying_params)
        self.global_seed(np.random, random, self.env, self.ood_env, seed=self.parameter.seed)
        torch.manual_seed(seed=self.parameter.seed)
        self.env_tasks = self.env.sample_tasks(self.parameter.task_num)
        self.test_tasks = self.env.sample_tasks(self.parameter.test_task_num)
        self.ood_tasks = self.ood_env.sample_tasks(self.parameter.test_task_num)
        self.training_agent = EnvRemoteArray(parameter=self.parameter, env_name=self.parameter.env_name,
                                             worker_num=1, seed=self.parameter.seed,
                                             deterministic=False, use_remote=False, policy_type=Policy,
                                             history_len=self.parameter.history_length, env_decoration=NonstationaryEnv,
                                             env_tasks=self.env_tasks,
                                             use_true_parameter=self.parameter.use_true_parameter,
                                             non_stationary=False)
        self.non_station_agent = EnvRemoteArray(parameter=self.parameter, env_name=self.parameter.env_name,
                                                worker_num=self.parameter.num_threads, seed=self.parameter.seed + 3,
                                                deterministic=True, use_remote=True, policy_type=Policy,
                                                history_len=self.parameter.history_length,
                                                env_decoration=NonstationaryEnv, env_tasks=self.test_tasks,
                                                use_true_parameter=self.parameter.use_true_parameter,
                                                non_stationary=True)
        self.policy_config['logger'] = self.logger
        self.value_config['logger'] = self.logger
        self.loaded_pretrain = not self.parameter.ep_pretrain_path_suffix == 'None'
        self.freeze_ep = False
        self.policy_config['freeze_ep'] = self.freeze_ep
        self.value_config['freeze_ep'] = self.freeze_ep
        self.obs_dim = self.non_station_agent.obs_dim
        self.act_dim = self.non_station_agent.act_dim
        self.policy = Policy(self.non_station_agent.obs_dim, self.non_station_agent.act_dim, **self.policy_config)

        self.value1 = Value(self.non_station_agent.obs_dim, self.non_station_agent.act_dim, **self.value_config)
        self.value2 = Value(self.non_station_agent.obs_dim, self.non_station_agent.act_dim, **self.value_config)
        self.target_value1 = Value(self.non_station_agent.obs_dim, self.non_station_agent.act_dim, **self.value_config)
        self.target_value2 = Value(self.non_station_agent.obs_dim, self.non_station_agent.act_dim, **self.value_config)
        self.tau = self.parameter.sac_tau
        self.target_entropy = -self.parameter.target_entropy_ratio * self.act_dim
        self.replay_buffer = MemoryNp(self.parameter.uniform_sample, self.parameter.rnn_slice_num)
        self.replay_buffer.set_max_size(self.parameter.sac_replay_size)
        self.policy_parameter = [*self.policy.parameters(True)]
        self.policy_optimizer = torch.optim.Adam(self.policy_parameter, lr=self.parameter.learning_rate)
        self.value_parameter = [*self.value1.parameters(True)] + [*self.value2.parameters(True)]
        self.value_optimizer = torch.optim.Adam(self.value_parameter,
                                                lr=self.parameter.value_learning_rate)
        self.device = torch.device('cuda', index=0) if torch.cuda.is_available() else torch.device('cpu')
        self.logger.log(f"torch device is {self.device}")
        self.log_sac_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                         ) * np.log(self.parameter.sac_alpha)).to(self.device).requires_grad_(True)
        self.alpha_optimizer = torch.optim.Adam([self.log_sac_alpha], lr=1e-2)
        self.vrdc_loss = VrdcLoss()
        to_device(self.device, self.policy, self.value1, self.value2, self.target_value1, self.target_value2)
        self.logger.log(f'size of parameter of policy: {len(self.policy_parameter)}, '
                        f'size of parameter of value: {len(self.value_parameter)}')
        self.all_repre = None
        self.all_valids = None
        self.all_repre_target = None
        self.all_valids_target = None
        self.all_tasks_validate = None
        self.log_consis_w_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                                      ) * np.log(1.0)).to(self.device).requires_grad_(
            True)
        self.log_diverse_w_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                                       ) * np.log(1.0)).to(self.device).requires_grad_(
            True)
        self.repre_loss_factor = 0.1
        self.w_optimizer = torch.optim.SGD([self.log_consis_w_alpha, self.log_diverse_w_alpha], lr=1e-1)
        self.w_log_max = 2.5
        self.env_param_dict = self.training_agent.make_env_param_dict()
        self.logger.log('environment parameter dict: ')
        self.logger.log_dict_single(self.env_param_dict)
        self.load(model_dir)
        self.logger.log('init done!!!')

    @staticmethod
    def global_seed(*args, seed):
        print('set seed to: {}'.format(seed))
        for item in args:
            item.seed(seed)

    @staticmethod
    def append_key(d, tail):
        res = {}
        for k, v in d.items():
            res[k+tail] = v
        return res

    def value_function_soft_update(self):
        self.target_value1.copy_weight_from(self.value1, self.tau)
        self.target_value2.copy_weight_from(self.value2, self.tau)

    def run(self):
        total_steps = 0
        for iter in range(self.parameter.max_iter_num):
            self.policy.to(torch.device('cpu'))
            future_ns = self.non_station_agent.submit_task(self.parameter.test_sample_num, self.policy)
            batch_non_station, log_non_station, mem_non_station = self.non_station_agent.query_sample(future_ns, need_memory=True)
            self.replay_buffer.mem_push_array(mem_non_station)
            self.replay_buffer.save_to_disk(Logger.get_replay_buffer_path(self.parameter))
            self.logger(f'saving replaybuffer to {Logger.get_replay_buffer_path(self.parameter)}, '
                        f'size of the replaybuffer is {self.replay_buffer.size}')
            training_end = time.time()
            self.logger.log('start testing...')

            testing_end = time.time()
            self.logger.add_tabular_data(**self.append_key(log_non_station, "NS"))
            self.logger.log_tabular('TotalInteraction', total_steps)
            self.logger.log_tabular('ReplayBufferTrajNum', len(self.replay_buffer))
            self.logger.log_tabular('ReplayBufferSize', self.replay_buffer.size)
            self.logger.log_tabular('TestingPeriod', testing_end - training_end)
            self.logger.add_tabular_data(**self.timer.summary())
            self.logger.dump_tabular()

    def save(self):
        self.policy.save(self.logger.model_output_dir)
        self.value1.save(self.logger.model_output_dir, 0)
        self.value2.save(self.logger.model_output_dir, 1)
        self.target_value1.save(self.logger.model_output_dir, "target0")
        self.target_value2.save(self.logger.model_output_dir, "target1")
        torch.save(self.policy_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'policy_optim.pt'))
        torch.save(self.value_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'value_optim.pt'))
        torch.save(self.alpha_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'alpha_optim.pt'))

    def load(self, model_path=None):
        model_load_path = model_path if model_path is not None else self.logger.model_output_dir
        self.policy.load(model_load_path, map_location=self.device)
        self.value1.load(model_load_path, 0, map_location=self.device)
        self.value2.load(model_load_path, 1, map_location=self.device)
        self.target_value1.load(model_load_path, "target0", map_location=self.device)
        self.target_value2.load(model_load_path, "target1", map_location=self.device)
        self.policy_optimizer.load_state_dict(torch.load(os.path.join(model_load_path, 'policy_optim.pt'),
                                                         map_location=self.device))
        self.value_optimizer.load_state_dict(torch.load(os.path.join(model_load_path, 'value_optim.pt'),
                                                        map_location=self.device))
        self.alpha_optimizer.load_state_dict(torch.load(os.path.join(model_load_path, 'alpha_optim.pt'),
                                                        map_location=self.device))


if __name__ == '__main__':
    import ray
    ray.init()
    parser = argparse.ArgumentParser(description=EXPERIMENT_TARGET)

    task_name = "Walker2d-v2-use_vrdc-rnn_len_32-enhance_ep-bottle_neck-stop_pg_for_ep-ep_dim_2-1_L2NORM_BOTTLE"
    parser.add_argument('--task_name', default=task_name, metavar='G',
                        help='model directory')
    seed = 1
    parser.add_argument('--seed', type=int, default=seed, metavar='N',
                        help='random seed (default: 1)')
    args = parser.parse_args()
    sac = NsDataConstructor(args.task_name, args.seed)
    sac.run()
