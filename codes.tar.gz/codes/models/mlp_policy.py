import torch.nn as nn
import torch
from utils.math import *
import numpy as np
activation_dict = {
    'tanh': torch.tanh,
    'relu': torch.relu,
    'sigmoid': torch.sigmoid
}

class Policy(nn.Module):
    def __init__(self, state_dim, action_dim, additional_dim, hidden_size=(128, 128), activation='tanh',
                 log_std=0, std_learnable=False, history_length=0):
        super().__init__()
        self.is_disc_action = False
        self.activation = activation_dict[activation]

        self.additional_dim = additional_dim
        # universe policy
        self.affine_layers = []
        last_dim = (state_dim + action_dim) * history_length + state_dim + additional_dim
        for nh in hidden_size:
            self.affine_layers.append(nn.Linear(last_dim, nh))
            last_dim = nh
        # env identifier


        self.action_mean = nn.Linear(last_dim, action_dim)
        self.action_mean.weight.data.mul_(0.1)
        self.action_mean.bias.data.mul_(0.0)

        # self.action_log_std = nn.Parameter(torch.ones(1, action_dim) * log_std)
        """set action log std a constant"""
        # self.action_log_std = nn.Parameter(torch.ones(1, action_dim) * log_std, requires_grad=False)
        if std_learnable:
            self.action_log_std = nn.Parameter(torch.ones(1, action_dim) * log_std, requires_grad=True)
        else:
            self.action_log_std = torch.ones(1, action_dim) * log_std
        self.std_learnable = std_learnable
        self.total_modules = nn.ModuleList(self.affine_layers)
        # self.action_log_std = (torch.ones(1, action_dim) * log_std)

    def forward(self, x):
        # calculate the mean value of action
        for affine in self.affine_layers:
            x = self.activation(affine(x))
        action_mean = torch.tanh(self.action_mean(x))


        if self.std_learnable:
            min_ = -3.0
            max_ = 0.5
            action_log_std_it = (torch.sigmoid(self.action_log_std)) * (max_ - min_) + min_

            action_log_std_it = torch.ones_like(action_log_std_it).expand_as(action_mean) * self.action_log_std
            action_log_std_it = action_log_std_it.to(x.device)
            action_log_std_it = (torch.ones_like(self.action_log_std).expand_as(action_mean) *
                                 action_log_std_it).to(action_mean.device)
        else:
            action_log_std_it = (torch.ones_like(self.action_log_std).expand_as(action_mean) *
                                 self.action_log_std).to(action_mean.device)
            # action_log_std = self.action_log_std.expand_as(action_mean).to(x.device)
        action_std = torch.exp(action_log_std_it)

        return action_mean, action_log_std_it, action_std

    def entropy(self, x):
        action_mean, action_log_std, action_std = self.forward(x)
        return action_log_std.sum(-1) * 0.5 + 0.5 * (np.log(2 * np.pi) + 1) * action_mean.shape[-1]

    def select_action(self, x):
        action_mean, _, action_std = self.forward(x)
        action = torch.randn_like(action_mean) * action_std + action_mean
        return action

    def select_action_reparam(self, x):
        action_mean, _, action_std = self.forward(x)
        action = torch.randn_like(action_mean) * action_std + action_mean
        return action

    def get_kl(self, x):
        mean1, log_std1, std1 = self.forward(x)

        mean0 = mean1.detach()
        log_std0 = log_std1.detach()
        std0 = std1.detach()
        kl = log_std1 - log_std0 + (std0.pow(2) + (mean0 - mean1).pow(2)) / (2.0 * std1.pow(2)) - 0.5
        return kl.sum(1, keepdim=True)

    def real_kl(self, x, other_mean, other_logstd, other_std):
        mean, log_std, std = self.forward(x)
        tmp_res = other_logstd - log_std + (std.pow(2) + (mean-other_mean).pow(2)) / (2.0 * other_std.pow(2)) - 0.5
        return tmp_res.sum(-1, keepdim=True)

    def get_log_prob(self, x, actions):
        action_mean, action_log_std, action_std = self.forward(x)
        return normal_log_density(actions, action_mean, action_log_std, action_std)

    def get_fim(self, x):
        mean, _, _ = self.forward(x)
        cov_inv = self.action_log_std.exp().pow(-2).squeeze(0).repeat(x.size(0)).to(mean.device)
        param_count = 0
        std_index = 0
        id = 0
        std_id = None
        for name, param in self.named_parameters():
            if name == "action_log_std":
                std_id = id
                std_index = param_count
            param_count += param.view(-1).shape[0]
            id += 1

        return cov_inv.detach(), mean, {'std_id': std_id, 'std_index': std_index}

    def reparameterize(self, x, action):
        action_mean, action_log_std, action_std = self.forward(x)
        return (action - action_mean).detach() + action_mean


