import torch


def get_rbf_matrix(data, centers, alpha):
    out_shape = torch.Size([data.shape[0], centers.shape[0], data.shape[-1]])
    data = data.unsqueeze(1).expand(out_shape)
    centers = centers.unsqueeze(0).expand(out_shape)
    mtx = (-(centers - data).pow(2) * alpha).exp().mean(dim=-1, keepdim=False)
    return mtx


def main():
    torch.manual_seed(1)
    y = torch.randn((10, 3))
    M = get_rbf_matrix(y, y, 1).detach()
    M2 = M.detach()
    M2 = M2.requires_grad_(True)
    M = M.requires_grad_(True)
    # logdet
    logdet = torch.logdet(M)
    logdet.backward()
    print(M.grad)
    loss2 = (M2 * torch.pinverse(M2).detach()).sum()
    print(loss2)
    loss2.backward()
    print(M2.grad)
    print((M.grad - M2.grad).abs().max())




if __name__ == '__main__':
    main()