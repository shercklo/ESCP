import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.policy import Policy
from log_util.logger import Logger
import torch

if __name__ == '__main__':
    logger = Logger()
    parameter = logger.parameter
    config = Policy.make_config_from_param(parameter)
    policy = Policy(obs_dim=5, act_dim=3, **config)
    policy.save(logger.model_output_dir)
    policy.load(logger.model_output_dir)
    device = torch.device('cuda', index=0) if torch.cuda.is_available() else torch.device('cpu')
    policy.to(device)
    policy.save(logger.model_output_dir)

    policy.load(logger.model_output_dir, map_location=device)
    policy.to(torch.device('cpu'))
    policy.load(logger.model_output_dir, map_location=torch.device('cpu'))

