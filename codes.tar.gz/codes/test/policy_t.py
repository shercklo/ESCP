import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.policy import Policy
from envs.nonstationary_env import NonstationaryEnv
from log_util.logger import Logger
import gym
import torch
import time
import numpy as np


if __name__ == '__main__':
    env = NonstationaryEnv(gym.make('Hopper-v2'))
    logger = Logger()
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    logger(f"obs dimension: {obs_dim}, act dimension: {act_dim}")
    # def __init__(self, obs_dim, act_dim, up_hidden_size, up_activations, up_layer_type,
    #                  ep_hidden_size, ep_activation, ep_layer_type, ep_dim, use_gt_env_feature):
    up_hidden_size = [256, 128, 64]
    up_activations = ['leaky_relu'] * len(up_hidden_size) + ['linear']
    up_layer_type = ['fc'] * len(up_activations)

    ep_hidden_size = [128, 64, 64]
    ep_dim = 32
    ep_layer_type = ['fc', 'lstm', 'lstm', 'fc']
    ep_activations = ['leaky_relu', 'linear', 'linear', 'tanh']
    policy = Policy(obs_dim, act_dim, up_hidden_size, up_activations, up_layer_type,
                    ep_hidden_size, ep_activations, ep_layer_type, ep_dim, False, logger)
    policy.save(logger.model_output_dir)
    policy.load(logger.model_output_dir)
    for i in range(10):
        state = env.reset()
        hidden_state = policy.make_init_state(1, None)
        lst_action = policy.make_init_action().cpu().numpy()
        done = False
        start_time = time.time()
        count = 0
        while not done:
            state_tensor = torch.Tensor(np.array(state).reshape((1, -1)))
            action_tensor = torch.Tensor(np.array(lst_action).reshape((1, -1)))
            action_mean, std, action, log_prob, hidden_state = policy.rsample(state_tensor, action_tensor, hidden_state)
            # action = env.action_space.sample()
            action_np = action.cpu().detach().numpy()
            state, reward, done, _ = env.step(action_np)
            lst_action = action_np
            count += 1
        logger(f'{i}, count: {count}, time: {time.time() - start_time}')


