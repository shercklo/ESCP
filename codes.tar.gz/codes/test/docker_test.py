import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os.path as osp
from parameter.private_config import *


def get_base_path():
    return osp.dirname(osp.dirname(osp.abspath(__file__)))


if __name__ == '__main__':
    base_path = get_base_path()
    docker_path = "/root/policy_adaptation"
    prefix = f'docker run --rm -it --shm-size 50gb -v  {base_path}:{docker_path} sanluosizhou/selfdl:latest -c '
    for item in os.listdir(os.path.join(base_path, 'test')):
        if '_t.py' in item:
            item_path = os.path.join(os.path.join(base_path, 'test'), item)
            cmd = prefix + f'"cd {docker_path} && python {docker_path}/test/{item}"'

            if item == 'parameter_t.py':
                cmd = cmd[:-1] + ' --use_vrdc "'
            system(cmd)
