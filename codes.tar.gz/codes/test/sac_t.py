import os, sys
import ray
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from algorithms.sac import SAC


if __name__ == '__main__':
    ray.init(log_to_driver=True)
    # exit(0)
    sac = SAC()
    sac.value_function_soft_update()
    sac.logger.log(sac.logger.parameter)
    sac.run()
