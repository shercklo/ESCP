import argparse
import yaml
from parameter.private_config import *

# template = "vdfe &&sleep {0} && export CUDA_VISIBLE_DEVICES={1} && cd SLBDAO/dfe_sac/src && python main.py --seed {2} --env_id {4} --info {5} --anchor_state_size {6} --preserve_ratio {7} "
base_path = get_base_path()
docker_path = "/root/policy_adaptation"
path = docker_path
tb_port = 6006
docker_template = f'docker run --rm -it --shm-size 50gb --gpus all -v {base_path}:{docker_path} sanluosizhou/selfdl:latest -c '
docker_template_port = f'docker run --rm -it --shm-size 50gb -v {base_path}:{docker_path} -p 6006:{tb_port} sanluosizhou/selfdl:latest -c '
template = 'export CUDA_VISIBLE_DEVICES={0} && cd {1} ' \
           '&& python test/vrdc_t.py --env_name {2} --seed {3} --model_dir {4}'
template2 = docker_template_port + '"sleep 25 && cd {0} && tensorboard --logdir=./log_file"'
template3 = docker_template + '"cd {0}"'
seeds = [99999]
config = {"session_name": "run-all-8619-v-{}".format(seeds[0]), "windows": []}
GPUS = [1]
rnn_slice_num = 16
# envs = ['HalfCheetah-v2-ep_dim_2-1_GENERATE_RP', 'Hopper-v2-ep_dim_2-1_GENERATE_RP', 'Walker2d-v2-ep_dim_2-1_GENERATE_RP', ]
# model_tasks_name = ['HalfCheetah-v2-use_vrdc-rnn_len_32-ep_dim_2-8989-debug_NJ',
#                     'Hopper-v2-use_vrdc-rnn_len_32-ep_dim_2-8989-debug_NJ',
#                     'Walker2d-v2-use_vrdc-rnn_len_32-ep_dim_2-8989-debug_NJ']
envs = ['Hopper-v2-ep_dim_2-1_GENERATE_RP',
        # 'HalfCheetah-v2-ep_dim_2-1_GENERATE_RP',
        # 'Walker2d-v2-ep_dim_2-1_GENERATE_RP',
        ]
model_tasks_name = ['Hopper-v2-use_vrdc-rnn_len_32-ep_dim_2-8989-debug_NJ',
                    # 'Hopper-v2-use_vrdc-rnn_len_32-ep_dim_2-8989-debug_NJ',
                    # 'Hopper-v2-use_vrdc-rnn_len_32-ep_dim_2-8989-debug_NJ',
                    ]
# envs = ['HalfCheetah-v2']
count_it = 0
algs = ['sac']
num_thread = 4
task_common_num = 40
common_hist_num = 0
mutual_information_ratio = 0.1
max_iter_num = 3000
uniform_sample_from_rb = False
rnn_fix_length = 32
test_task_num = 40
share_ep = False
test_sample_num = 12000
ep_dim = 2
load_pretrain = False
varying_params = [
    ' gravity ',
]

imitate_update_interval = 50
for env_ind, env in enumerate(envs):
    for seed in seeds:
        gpu_ind = GPUS[count_it % len(GPUS)]
        count_it += 1
        panes_list = []
        total_cmd = template.format(gpu_ind, docker_path, env, seed,  model_tasks_name[env_ind])
        if load_pretrain:
            total_cmd += ' --load_pretrain '
        script_it = docker_template + "\"" + total_cmd + "\""
        print(script_it)
        panes_list.append(script_it)
        config["windows"].append({
            "window_name": "{}".format(env),
            "panes": panes_list,
            "layout": "tiled"
        })

config["windows"].append({
        "window_name": "tensorboard",
        "panes": [template2.format(path)],
        "layout": "tiled"
    })
print(template2.format(path))

config["windows"].append({
        "window_name": "init_operation",
        "panes": [template3.format(path)],
        "layout": "tiled"
    })
print(template3.format(path))
yaml.dump(config, open("run_all.yaml", "w"), default_flow_style=False)
