import torch.nn as nn
import torch

activation_dict = {
    'tanh': torch.tanh,
    'relu': torch.relu,
    'sigmoid': torch.sigmoid
}

class DoubleQValue(nn.Module):
    def __init__(self, state_action_dim, hidden_size=(128, 256, 128), activation='tanh', history_length=0,
                 pure_state_action_length=0, use_vrdc=False, env_parameter_length=32):
        super(DoubleQValue, self).__init__()
        self.activation = activation_dict[activation]
        self.history_length = history_length
        self.pure_state_action_length = pure_state_action_length
        self.env_parameter_length = env_parameter_length
        self.use_vrdc = use_vrdc
        """--------------------------------"""
        # start system identifier
        self.identifier_layers1 = []
        last_dim = history_length
        for nh in [256, 128]:
            self.identifier_layers1.append(nn.Linear(last_dim, nh))
            last_dim = nh
        self.env_parameter_head1 = nn.Linear(last_dim, self.env_parameter_length)
        # end system identifier
        self.affine_layers1 = []
        last_dim = pure_state_action_length + self.env_parameter_length
        for nh in hidden_size:
            self.affine_layers1.append(nn.Linear(last_dim, nh))
            last_dim = nh

        self.value_head1 = nn.Linear(last_dim, 1)
        self.value_head1.weight.data.mul_(0.1)
        self.value_head1.bias.data.mul_(0.0)
        """--------------------------------"""
        # start system identifier
        self.identifier_layers2 = []
        last_dim = history_length
        for nh in [256, 128]:
            self.identifier_layers2.append(nn.Linear(last_dim, nh))
            last_dim = nh
        self.env_parameter_head2 = nn.Linear(last_dim, self.env_parameter_length)
        # end system identifier
        self.affine_layers2 = []
        last_dim = pure_state_action_length + self.env_parameter_length
        for nh in hidden_size:
            self.affine_layers2.append(nn.Linear(last_dim, nh))
            last_dim = nh

        self.value_head2 = nn.Linear(last_dim, 1)
        self.value_head2.weight.data.mul_(0.1)
        self.value_head2.bias.data.mul_(0.0)
        """--------------------------------"""
        self.module_list = nn.ModuleList(self.affine_layers1 + self.affine_layers2 +
                                         [self.value_head1] + [self.value_head2] +
                                         self.identifier_layers1 + self.identifier_layers2 +
                                         [self.env_parameter_head1] + [self.env_parameter_head2])

    def get_env_predict1(self, x):
        env_parameter_input = x[:, :self.history_length]
        for affine in self.identifier_layers1:
            env_parameter_input = self.activation(affine(env_parameter_input))
        env_parameter_input = torch.tanh(self.env_parameter_head1(env_parameter_input))
        return env_parameter_input

    def get_env_predict2(self, x):
        env_parameter_input = x[:, :self.history_length]
        for affine in self.identifier_layers2:
            env_parameter_input = self.activation(affine(env_parameter_input))
        env_parameter_input = torch.tanh(self.env_parameter_head2(env_parameter_input))
        return env_parameter_input

    def forward(self, x):
        x1 = x[:, -self.pure_state_action_length:]
        pred1 = self.get_env_predict1(x)
        #if self.use_vrdc:
        #    pred1 = pred1.detach()
        x1 = torch.cat([x1, pred1], -1)
        for affine in self.affine_layers1:
            x1 = self.activation(affine(x1))
        value1 = self.value_head1(x1)

        x2 = x[:, -self.pure_state_action_length:]
        pred2 = self.get_env_predict2(x)
        #if self.use_vrdc:
        #    pred2 = pred2.detach()
        x2 = torch.cat([x2, pred2], -1)
        for affine in self.affine_layers2:
            x2 = self.activation(affine(x2))
        value2 = self.value_head2(x2)

        return value1, value2

    def soft_update_params_from(self, net, tau):
        """I am target net, tau ~~ 1"""
        with torch.no_grad():
            for param, target_param in zip(net.parameters(True), self.parameters(True)):
                target_param.data.mul_(tau)
                target_param.data.add_((1-tau) * param.data)
            # if self.use_vrdc:
            if False:
                for param, target_param in zip(net.identifier_layers1 + [net.env_parameter_head1] +
                                           net.identifier_layers2 + [net.env_parameter_head2],
                                           self.identifier_layers1 + [self.env_parameter_head1] +
                                           self.identifier_layers2 + [self.env_parameter_head2]):
                    for sub_param, sub_target_param in zip(param.parameters(True), target_param.parameters(True)):
                        sub_target_param.data.mul_(0.0)
                        sub_target_param.data.add_(sub_param.data)