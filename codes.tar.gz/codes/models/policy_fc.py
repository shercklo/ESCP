from models.rnn_base import RNNBase
import torch
from torch.distributions import Normal
import numpy as np
import os


class Policy(torch.nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size, activations, layer_type, logger=None):
        super(Policy, self).__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.policy = RNNBase(obs_dim, act_dim * 2, hidden_size, activations, layer_type, logger)
        self.module_list = torch.nn.ModuleList(self.policy.total_module_list)
        self.min_log_std = -4.0
        self.max_log_std = 2.0

    def meta_forward(self, x):
        return self.policy.meta_forward(x, None)[0]

    def forward(self, x):
        policy_out = self.meta_forward(x)
        mu, log_std = policy_out.chunk(2, dim=-1)
        log_std = torch.clamp(log_std, self.min_log_std, self.max_log_std)
        std = log_std.exp()
        return mu, std

    def rsample(self, x):
        mu, std = self.forward(x)
        dist = Normal(mu, std)
        sample = dist.rsample()
        log_prob = dist.log_prob(sample).sum(-1, keepdim=True)
        log_prob = log_prob - (2 * (np.log(2) - sample -
                                    torch.nn.functional.softplus(-2 * sample))).sum(-1, keepdim=True)
        return torch.tanh(mu), std, torch.tanh(sample), log_prob

    def save(self, path):
        self.policy.save(os.path.join(path, 'policy.pt'))

    def load(self, path, **kwargs):
        self.policy.load(os.path.join(path, 'policy.pt'), **kwargs)

    @staticmethod
    def make_config_from_param(parameter):
        return dict(
            hidden_size=parameter.hidden_size,
            activations=parameter.activations,
            layer_type=parameter.layer_type
        )

    def inference_one_step(self, state, deterministic=True):
        with torch.no_grad():
            # lst_action = state[..., :self.act_dim]
            state = state[..., self.act_dim:]
            mu, std, act, logp = self.rsample(state)
        if deterministic:
            return mu
        return act

    def inference_check_hidden(self, *args, **kwargs):
        return True

    def inference_init_hidden(self, *args, **kwargs):
        pass