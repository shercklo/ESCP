#! /bin/bash
bash stop_docker.sh && bash clear_log.sh && bash start.sh