import torch.nn as nn
import torch
from utils.math import *
import numpy as np
from utils.torch_utils import SquashedNormal
from torch.distributions import Normal
activation_dict = {
    'tanh': torch.tanh,
    'relu': torch.relu,
    'sigmoid': torch.sigmoid
}

class Policy(nn.Module):
    def __init__(self, state_dim, action_dim, additional_dim, hidden_size=(256, 256), activation='tanh',
                 log_std=0, std_learnable=False, history_length=0, use_vrdc=False):
        super(Policy, self).__init__()
        self.is_disc_action = False
        self.use_vrdc = use_vrdc
        self.activation = activation_dict[activation]
        self.additional_dim = additional_dim
        self.history_length = history_length
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.env_parameter_length = 32
        # universe policy
        self.affine_layers = []
        last_dim = state_dim + self.env_parameter_length + additional_dim
        for nh in hidden_size:
            self.affine_layers.append(nn.Linear(last_dim, nh))
            last_dim = nh
        # environment identifier
        self.identifier_layers = []
        last_dim = (state_dim + action_dim) * history_length + state_dim
        for nh in [256, 128]:
            self.identifier_layers.append(nn.Linear(last_dim, nh))
            last_dim = nh
        self.env_parameter_head = nn.Linear(last_dim, self.env_parameter_length)
        if std_learnable:
            self.action_log_std = nn.Parameter(torch.ones(1, action_dim) * log_std, requires_grad=True)
        else:
            self.action_log_std = torch.ones(1, action_dim) * log_std

        self.action_mean = nn.Linear(last_dim, action_dim )
        self.action_mean.weight.data.mul_(0.1)
        self.action_mean.bias.data.mul_(0.0)

        self.min_log_std = -5.0
        self.max_log_std = 2.0
        self.module_list = nn.ModuleList(self.affine_layers + [self.action_mean] + self.identifier_layers + [self.env_parameter_head])
        # self.action_log_std = (torch.ones(1, action_dim) * log_std)

    def copy_weight_from(self, data, w=1.0):
        with torch.no_grad():
            for param, target_param in zip(data, self.identifier_layers + [self.env_parameter_head]):
                for sub_param, sub_target_param in zip(param.parameters(True), target_param.parameters(True)):
                    sub_target_param.data.mul_(1 - 0.0)
                    sub_target_param.data.add_(sub_param.data * w)


    def get_env_predict(self, x):
        env_parameter_input = x[:, :((self.state_dim + self.action_dim) * self.history_length + self.state_dim)]
        for affine in self.identifier_layers:
            env_parameter_input = self.activation(affine(env_parameter_input))
        env_parameter_input = torch.tanh(self.env_parameter_head(env_parameter_input))
        return env_parameter_input

    def forward_without_parameter_input(self, x):
        # calculate the mean value of action distribution
        current_state = x[:, ((self.state_dim + self.action_dim) * self.history_length): ((self.state_dim +
                                                                                           self.action_dim) * self.history_length + self.state_dim + self.additional_dim)]
        if self.additional_dim > 0:
            current_state[:, -self.additional_dim:] = 0
        # env_parameter_input = self.get_env_predict(x)
        x = torch.cat((current_state, torch.zeros((current_state.shape[0], self.env_parameter_length),
                                                  dtype=x.dtype, device=x.device)), -1)

        for affine in self.affine_layers:
            x = self.activation(affine(x))

        # mu, std
        mu = torch.tanh(self.action_mean(x))
        log_std = self.action_log_std.to(device=x.device, dtype=x.dtype)
        # log_std = self.min_log_std + 0.5 * (self.max_log_std - self.min_log_std) * (log_std + 1)
        std = log_std.exp()
        dist = Normal(mu, std)

        return mu, log_std, dist


    def forward(self, x):
        # calculate the mean value of action distribution
        current_state = x[:, ((self.state_dim + self.action_dim) * self.history_length) : ((self.state_dim +
                                    self.action_dim) * self.history_length + self.state_dim + self.additional_dim)]
        env_parameter_input = self.get_env_predict(x)
        if self.use_vrdc:
            env_parameter_input = env_parameter_input.detach()
        x = torch.cat((current_state, env_parameter_input), -1)

        for affine in self.affine_layers:
            x = self.activation(affine(x))

        # mu, std
        mu = torch.tanh(self.action_mean(x))
        log_std = self.action_log_std.to(device=x.device, dtype=x.dtype)
        # log_std = self.min_log_std + 0.5 * (self.max_log_std - self.min_log_std) * (log_std + 1)
        std = log_std.exp()
        dist = Normal(mu, std)

        return mu, log_std, dist

    def entropy(self, x):
        mu, log_std, dist = self.forward(x)
        return dist.entropy().sum(-1, keepdim=True)

    def std(self, x):
        mu, log_std, _ = self.forward(x)
        return log_std.exp().mean(-1, keepdim=True)

    def select_action(self, x):
        _, _, dist = self.forward(x)
        return dist.rsample()

    def select_action_with_logprob(self, x):
        _, log_std, dist = self.forward(x)
        samples = dist.rsample()
        res_samples = samples
        log_prob = dist.log_prob(samples).sum(-1, keepdim=True)
        # log_prob = normal_log_density(samples, dist.mean, log_std, log_std.exp())
        # log_prob = dist.log_prob(samples).sum(-1, keepdim=True)
        return res_samples, log_prob

    def select_action_reparam(self, x):
        _, _, dist = self.forward(x)
        return dist.rsample()

    def real_kl(self, x, other_mean, other_logstd, other_std):
        mean, log_std, dist = self.forward(x)
        std = log_std.exp()
        tmp_res = other_logstd - log_std + (std.pow(2) + (mean-other_mean).pow(2)) / (2.0 * other_std.pow(2)) - 0.5
        return tmp_res.sum(-1, keepdim=True)

    def get_log_prob(self, x, actions):
        action_mean, action_log_std, dist = self.forward(x)
        return dist.log_prob(actions)

