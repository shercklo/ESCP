FILE_NAME="middle_server_code_2"
SUB_IP="10.200.0.37"
SUB_IP_PW="xjXMAwCXxiLCYym"

MIDDLE_SERVER_IP="58.211.191.23"
MIDDLE_SERVER_PASSWD="ZYd9feaL9032x71"
sshpass -p $MIDDLE_SERVER_PASSWD ssh -p 50022 ubuntu@$MIDDLE_SERVER_IP "rm -rf Downloads/$FILE_NAME"
sshpass -p $MIDDLE_SERVER_PASSWD scp -r -P 50022 /home/luofm/Downloads/middle_server_2 ubuntu@$MIDDLE_SERVER_IP:Downloads/$FILE_NAME
sshpass -p $MIDDLE_SERVER_PASSWD ssh -p 50022 ubuntu@$MIDDLE_SERVER_IP "sshpass -p $SUB_IP_PW scp -r /home/ubuntu/Downloads/$FILE_NAME ubuntu@$SUB_IP:"