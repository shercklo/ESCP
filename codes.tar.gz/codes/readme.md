# 怎么运行
直接在docker目录下，把能用的企业版mujoco的mjkey.txt复制到conf目录下，然后直接运行
```shell script
bash build_docker.sh
```
然后在主目录下，直接运行（需要管理员权限）。
```shell script
bash debug.sh
```
所有东西（跑的程序，tensorboard）就都跑起来了。
环境和参数配置在generate_tmux.py里