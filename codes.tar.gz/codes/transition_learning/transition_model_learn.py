import os, sys
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from log_util.logger import Logger
from models.value import Value
from models.policy import Policy
from models.transition import Trainsition
from parameter.private_config import *
from agent.Agent import EnvRemoteArray
from envs.nonstationary_env import NonstationaryEnv
from utils.replay_memory import Memory, MemoryNp
import gym
import torch
import numpy as np
import random
from utils.torch_utils import to_device
import time
from utils.timer import Timer
from algorithms.vrdc import VrdcLoss
from tqdm import tqdm
from utils.visualize_repre import visualize_repre, visualize_repre_real_param
from parameter.Parameter import Parameter
import argparse


# docker run --rm -it --shm-size 50gb -v $PWD:/root/workspace sanluosizhou/selfdl:latest -c "export CUDA_VISIBLE_DEVICES=1 && cd /root/workspace/ && python transition_learning/transition_model_learn.py --seed 1 "
class TransitionModelLearn:
    def __init__(self, task_name, seed, replay_buffer_task_name, validate_rp_task_name):
        parameter = Parameter(config_path=os.path.join(get_base_path(), 'log_file', task_name), debug=True,
                              information='model_learn')
        replay_buffer_dir = os.path.join(get_base_path(), 'log_file', replay_buffer_task_name, 'replay_buffer.pkl')
        validate_replay_buffer_dir = os.path.join(get_base_path(), 'log_file', validate_rp_task_name, 'replay_buffer.pkl')

        parameter.seed = seed
        parameter.num_threads = 8
        parameter.max_iter_num = 1800
        parameter.min_batch_size = 1

        model_dir = os.path.join(get_base_path(), 'log_file', task_name, 'model')
        self.logger = Logger(parameter=parameter)
        self.logger.log(parameter)
        # self.logger.set_tb_x_label('TotalInteraction')
        self.timer = Timer()
        self.parameter = self.logger.parameter
        self.policy_config = Trainsition.make_config_from_param(self.parameter)
        self.value_config = Value.make_config_from_param(self.parameter)
        self.env = NonstationaryEnv(gym.make(self.parameter.env_name), log_scale_limit=ENV_DEFAULT_CHANGE,
                                    rand_params=self.parameter.varying_params)
        self.ood_env = NonstationaryEnv(gym.make(self.parameter.env_name), log_scale_limit=4.0,
                                        rand_params=self.parameter.varying_params)
        self.global_seed(np.random, random, self.env, self.ood_env, seed=self.parameter.seed)
        torch.manual_seed(seed=self.parameter.seed)
        self.env_tasks = self.env.sample_tasks(self.parameter.task_num)
        self.test_tasks = self.env.sample_tasks(self.parameter.test_task_num)
        self.ood_tasks = self.ood_env.sample_tasks(self.parameter.test_task_num)
        self.training_agent = EnvRemoteArray(parameter=self.parameter, env_name=self.parameter.env_name,
                                             worker_num=1, seed=self.parameter.seed,
                                             deterministic=False, use_remote=False, policy_type=Policy,
                                             history_len=self.parameter.history_length, env_decoration=NonstationaryEnv,
                                             env_tasks=self.env_tasks,
                                             use_true_parameter=self.parameter.use_true_parameter,
                                             non_stationary=False)
        self.policy_config['logger'] = self.logger
        self.loaded_pretrain = not self.parameter.ep_pretrain_path_suffix == 'None'
        self.freeze_ep = True
        self.policy_config['freeze_ep'] = self.freeze_ep
        self.obs_dim = self.training_agent.obs_dim
        self.act_dim = self.training_agent.act_dim
        self.transition = Trainsition(self.training_agent.obs_dim, self.training_agent.act_dim, **self.policy_config)

        self.tau = self.parameter.sac_tau
        self.target_entropy = -self.parameter.target_entropy_ratio * self.act_dim

        self.replay_buffer = MemoryNp(self.parameter.uniform_sample, self.parameter.rnn_slice_num)
        self.logger(f"slice num is {self.parameter.rnn_slice_num}")
        self.replay_buffer.set_max_size(self.parameter.sac_replay_size)
        self.replay_buffer.load_from_disk(replay_buffer_dir)
        self.replay_buffer.rnn_slice_length = self.parameter.rnn_slice_num
        self.validate_replay_buffer = MemoryNp(self.parameter.uniform_sample, self.parameter.rnn_slice_num)
        self.logger(f"slice num is {self.parameter.rnn_slice_num}")
        self.validate_replay_buffer.set_max_size(self.parameter.sac_replay_size)
        self.validate_replay_buffer.load_from_disk(validate_replay_buffer_dir)
        self.validate_replay_buffer.rnn_slice_length = self.parameter.rnn_slice_num

        self.policy_parameter = [*self.transition.parameters(True)]
        self.policy_optimizer = torch.optim.Adam(self.policy_parameter, lr=self.parameter.learning_rate)
        self.device = torch.device('cuda', index=0) if torch.cuda.is_available() else torch.device('cpu')
        self.logger.log(f"torch device is {self.device}")
        self.log_sac_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                         ) * np.log(self.parameter.sac_alpha)).to(self.device).requires_grad_(True)
        self.alpha_optimizer = torch.optim.Adam([self.log_sac_alpha], lr=1e-2)
        self.vrdc_loss = VrdcLoss()
        to_device(self.device, self.transition)
        self.logger.log(f'size of parameter of policy: {len(self.policy_parameter)}')
        self.all_repre = None
        self.all_valids = None
        self.all_repre_target = None
        self.all_valids_target = None
        self.all_tasks_validate = None
        self.log_consis_w_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                                      ) * np.log(1.0)).to(self.device).requires_grad_(
            True)
        self.log_diverse_w_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                                       ) * np.log(1.0)).to(self.device).requires_grad_(
            True)
        self.repre_loss_factor = 0.1
        self.w_optimizer = torch.optim.SGD([self.log_consis_w_alpha, self.log_diverse_w_alpha], lr=1e-1)
        self.w_log_max = 2.5
        self.env_param_dict = self.training_agent.make_env_param_dict()
        self.logger.log('environment parameter dict: ')
        self.logger.log_dict_single(self.env_param_dict)
        self.logger.log('loading EP model from {}'.format(model_dir))
        self.transition.ep.load(os.path.join(model_dir, 'environment_probe.pt'), map_location=self.device)

    @staticmethod
    def global_seed(*args, seed):
        for item in args:
            item.seed(seed)

    def sac_update(self, state, action, next_state, reward, mask, last_action, valid, task,
                   policy_hidden=None, value_hidden1=None, value_hidden2=None, validate=False):
        """reward, mask should be (-1, 1)"""
        alpha = self.log_sac_alpha.exp()
        if self.parameter.rnn_fix_length is None or self.parameter.rnn_fix_length == 0:
            valid_num = valid.sum()
        else:
            valid_num = valid[..., -1:, :].sum()
        # if not FC_MODE:
        vrdc_loss_tensor = consistency_loss = diverse_loss = None
        batch_task_num = 1
        """update critic/value net"""
        self.timer.register_point('calculating_target_Q', level=3)     # (TIME: 0.011)
        consis_w = torch.exp(self.log_consis_w_alpha)
        diverse_w = torch.exp(self.log_diverse_w_alpha)
        consis_w_loss = None
        diverse_w_loss = None
        """update policy and alpha"""
        self.timer.register_point('actor_loss', level=3)     # (TIME: 0.012)
        action_mean, _, action_rsample, logprob, _ = self.transition.rsample(state, action, last_action, policy_hidden)
        ep = self.transition.ep_tensor
        actor_loss = (action_mean - next_state).pow(2)
        if self.parameter.rnn_fix_length:
            actor_loss, valid = map(lambda x: x[..., -1:, :],
                                                     [actor_loss, valid])
        actor_loss = (actor_loss).sum() / valid_num
        self.timer.register_point('policy_optimization', level=3)     # (TIME: 0.026)
        self.policy_optimizer.zero_grad()
        if torch.isnan(actor_loss).any().item():
            self.logger.log(f"nan found in actor loss, state: {state.abs().sum()}, "
                            f"last action: {last_action.abs().sum()}, "
                            f"action: {action.abs().sum()}")
            return None
        actor_loss.backward()
        policy_gradient = torch.nn.utils.clip_grad.clip_grad_norm_(self.policy_parameter,
                                                                   self.parameter.policy_max_gradient)
        if not validate:
            self.policy_optimizer.step()
        self.timer.register_end(level=3)
        w_loss = 0
        with torch.no_grad():
            self.log_diverse_w_alpha.clamp_max_(self.w_log_max)
            self.log_consis_w_alpha.clamp_max_(self.w_log_max)
        self.value_function_soft_update()
        # if self.parameter.use_vrdc and not self.parameter.share_ep:
        #     self.policy.apply_temp_ep(0.99)
        return dict(
            ActorLoss=actor_loss.item(),
            PolicyGradient=policy_gradient,
        )

    def sac_update_from_buffer(self, validate=False):
        log = {}
        replay_buffer = self.replay_buffer if not validate else self.validate_replay_buffer
        for _ in range(self.parameter.update_interval):
            self.timer.register_point('sample_from_replay', level=1)     # (TIME: 0.4)
            if FC_MODE:
                batch = replay_buffer.sample_transitions(self.parameter.sac_mini_batch_size)
            else:
                if self.parameter.rnn_fix_length:
                    batch = replay_buffer.sample_fix_length_sub_trajs(self.parameter.sac_mini_batch_size,
                                                                           self.parameter.rnn_fix_length)
                else:
                    batch, total_size = replay_buffer.sample_trajs(self.parameter.sac_mini_batch_size,
                                                        self.parameter.rnn_sample_max_batch_size)
                # self.logger.log(f'total transition in the trajectories is {total_size}, state shape: {np.array(batch.state).shape}')

            dtype = torch.get_default_dtype()
            device = self.device
            # self.logger(np.array(batch.state), np.array(batch.reward))
            states, next_states, actions, last_action, rewards, masks, valid, task = \
                    map(lambda x: torch.from_numpy(np.array(x)).to(dtype=dtype, device=device),
                    [batch.state, batch.next_state, batch.action, batch.last_action,
                        batch.reward, batch.mask, batch.valid, batch.task])
            hidden_value1 = hidden_value2 = []
            if not FC_MODE:
                self.timer.register_point('making_slice', level=3)     # (TIME: 0.14)
                if self.parameter.rnn_fix_length is None or self.parameter.rnn_fix_length == 0:
                    self.timer.register_point('generate_hidden_state', level=4)
                    hidden_policy = self.transition.generate_hidden_state(states, last_action,
                                                                          slice_num=self.parameter.rnn_slice_num)
                    self.timer.register_point('Policy.slice_tensor', level=4)
                    states, next_states, actions, last_action, rewards, masks, valid, task = \
                        map(Trainsition.slice_tensor, [states, next_states, actions, last_action, rewards, masks, valid, task],
                            [self.parameter.rnn_slice_num] * 8)
                    self.timer.register_point('Policy.merge_slice_tensor', level=4)
                    states, next_states, actions, last_action, rewards, masks, valid, task = Trainsition.merge_slice_tensor(
                        states, next_states, actions, last_action, rewards, masks, valid, task
                    )
                    mask_for_valid = valid.sum(dim=-2, keepdim=True)[..., 0, 0] > 0
                    states, next_states, actions, last_action, rewards, masks, valid, task = map(
                        lambda x: x[mask_for_valid],
                        [states, next_states, actions, last_action, rewards, masks, valid, task]
                    )
                    hidden_policy, hidden_value1, hidden_value2 = map(
                        Trainsition.hidden_state_mask,
                        [hidden_policy, hidden_value1, hidden_value2],
                        [mask_for_valid, mask_for_valid, mask_for_valid]
                    )
                    self.timer.register_end(level=4)
                else:
                    self.timer.register_point('Policy.slice_tensor', level=4)     # (TIME: 0.132)
                    # states, next_states, actions, last_action, rewards, masks, valid, task = \
                    #     map(Policy.slice_tensor_overlap, [states, next_states, actions, last_action, rewards, masks, valid, task],
                    #         [self.parameter.rnn_fix_length] * 8)
                    self.timer.register_end(level=4)
                    # mask_for_valid = valid[..., -1, 0] == 1
                    # states, next_states, actions, last_action, rewards, masks, valid, task = \
                    #     map(lambda x: x[mask_for_valid], [states, next_states, actions, last_action,
                    #                                       rewards, masks, valid, task])
                    self.timer.register_point('generate_hidden_state', level=4)
                    hidden_policy = self.transition.make_init_state(batch_size=states.shape[0], device=states.device)
                    self.timer.register_end(level=4)
                self.timer.register_end(level=3)
            else:
                hidden_policy, hidden_value1, hidden_value2 = [], [], []
            self.timer.register_end(level=1)
            #if custom_additional_reward is not None:
            #    with torch.no_grad():
            #        rewards = rewards + custom_additional_reward(states)
            states, next_states, actions, last_action, rewards, masks, valid, task = map(
                lambda x: x.detach(),
                [states, next_states, actions, last_action, rewards, masks, valid, task]
            )
            hidden_policy, hidden_value1, hidden_value2 = map(
                Trainsition.hidden_detach,
                [hidden_policy, hidden_value1, hidden_value2]
            )
            with torch.set_grad_enabled(True):
                if FC_MODE:
                    self.timer.register_point('self.sac_update', level=1)
                    res_dict = self.sac_update(states, actions, next_states,
                                               rewards, masks, last_action, valid, task, hidden_policy,
                                               hidden_value1, hidden_value2, validate)
                    self.timer.register_end(level=1)
                else:
                    point_num = states.shape[0]
                    total_inds = np.random.permutation(point_num).tolist()
                    iter_batch_size = states.shape[0] // 10
                    # self.logger(f'valid traj num: {states.shape[0]}, batch size: {iter_batch_size}')
                    for i in range(self.parameter.sac_inner_iter_num):
                        self.timer.register_point('sample_from_batch', level=1)     # (TIME: 0.003)
                        while True:
                            inds = random.sample(total_inds, iter_batch_size)
                            # inds = total_inds[i * iter_batch_size : min((i + 1) * iter_batch_size, point_num)]
                            states_batch, next_states_batch, actions_batch, \
                            last_action_batch, rewards_batch, masks_batch, valid_batch, task_batch = \
                            map(lambda x: x[inds], [
                                states, next_states, actions, last_action, rewards, masks, valid, task
                            ])
                            if self.parameter.rnn_fix_length:
                                if valid_batch[..., -1:, :].sum().item() >= 2:
                                    break
                            elif valid_batch.sum().item() >= 2:
                                break
                            # total_inds = np.random.permutation(point_num)
                        hidden_policy_batch, hidden_value1_batch, hidden_value2_batch = \
                            map(Trainsition.hidden_state_sample,
                                [hidden_policy, hidden_value1, hidden_value2],
                                [inds, inds, inds])
                        self.timer.register_point('self.sac_update', level=1)     # (TIME: 0.091)
                        res_dict = self.sac_update(states_batch, actions_batch, next_states_batch, rewards_batch,
                                                   masks_batch, last_action_batch, valid_batch, task_batch,
                                                   hidden_policy_batch, hidden_value1_batch, hidden_value2_batch, validate)
                        self.timer.register_end(level=1)
                if res_dict is not None:
                    for key in res_dict:
                        if key in log:
                            log[key].append(res_dict[key])
                        else:
                            log[key] = [res_dict[key]]
        return log

    def update(self, validate=False):
        # TODO (luofm): conditionally setting validate flag!!
        log = self.sac_update_from_buffer(validate)

        return log

    @staticmethod
    def append_key(d, tail):
        res = {}
        for k, v in d.items():
            res[k+tail] = v
        return res

    def value_function_soft_update(self):
        pass

    def run(self):
        total_steps = 0
        if self.replay_buffer.size < self.parameter.start_train_num:
            self.logger(f"init samples!!!")
            self.transition.to(self.device)
            while self.replay_buffer.size < self.parameter.start_train_num:
                mem, log = self.training_agent.sample1step(self.transition,
                                                           self.replay_buffer.size < self.parameter.random_num,
                                                           device=self.device)
                self.replay_buffer.mem_push(mem)
                total_steps += 1
            self.logger("init done!!!")
        for iter in range(self.parameter.max_iter_num):
            self.transition.to(torch.device('cpu'))
            self.transition.to(self.device)
            training_start = time.time()
            single_step_iterater = range(self.parameter.min_batch_size) if not USE_TQDM else\
                tqdm(range(self.parameter.min_batch_size))
            for step in single_step_iterater:
                self.timer.register_point('self.update')
                update_log = self.update()
                self.timer.register_end()
                log = update_log
                self.logger.add_tabular_data(**log)
            training_end = time.time()
            self.logger.log('start testing...')
            testing_end = time.time()
            self.logger.log_tabular('TotalInteraction', total_steps)
            self.logger.log_tabular('ReplayBufferTrajNum', len(self.replay_buffer))
            self.logger.log_tabular('ReplayBufferSize', self.replay_buffer.size)
            self.logger.log_tabular('TrainingPeriod', training_end - training_start)
            self.logger.log_tabular('TestingPeriod', testing_end - training_end)
            self.logger.add_tabular_data(**self.timer.summary())
            self.save()
            self.logger.dump_tabular()

    def save(self):
        self.transition.save(self.logger.model_output_dir)
        torch.save(self.policy_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'policy_optim.pt'))
        torch.save(self.alpha_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'alpha_optim.pt'))

    def load(self):
        self.transition.load(self.logger.model_output_dir, map_location=self.device)
        self.policy_optimizer.load_state_dict(torch.load(os.path.join(self.logger.model_output_dir, 'policy_optim.pt'),
                                                         map_location=self.device))
        self.alpha_optimizer.load_state_dict(torch.load(os.path.join(self.logger.model_output_dir, 'alpha_optim.pt'),
                                                        map_location=self.device))


if __name__ == '__main__':
    import ray

    ray.init()
    parser = argparse.ArgumentParser(description=EXPERIMENT_TARGET)

    task_name = "Walker2d-v2-use_vrdc-rnn_len_32-enhance_ep-bottle_neck-stop_pg_for_ep-ep_dim_2-1_L2NORM_BOTTLE"
    parser.add_argument('--task_name', default=task_name, metavar='G',
                        help='model directory')

    rp_name = "Walker2d-v2-use_vrdc-rnn_len_32-enhance_ep-bottle_neck-stop_pg_for_ep-ep_dim_2-1_L2NORM_BOTTLE"
    parser.add_argument('--rp_name', default=rp_name, metavar='G',
                        help='replay data directory')

    val_rp_name = "Walker2d-v2-use_vrdc-rnn_len_32-enhance_ep-bottle_neck-stop_pg_for_ep-ep_dim_2-1_L2NORM_BOTTLE"
    parser.add_argument('--val_rp_name', default=val_rp_name, metavar='G',
                        help='validation replay data directory')
    seed = 1
    parser.add_argument('--seed', type=int, default=seed, metavar='N',
                        help='random seed (default: 1)')
    args = parser.parse_args()
    sac = TransitionModelLearn(args.task_name, args.seed, args.rp_name, args.val_rp_name)
    sac.run()
