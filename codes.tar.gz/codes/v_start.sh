#! /bin/bash
python3 v_generate_tmuxp.py && tmuxp load run_all.yaml