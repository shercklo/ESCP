import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from envs.nonstationary_env import NonstationaryEnv
import gym
from parameter.Parameter import Parameter
import time

if __name__ == '__main__':
    parameter = Parameter()
    env = NonstationaryEnv(gym.make(parameter.env_name), parameter.varying_params)

    for i in range(100):
        env.reset()
        done = False
        start_time = time.time()
        steps = 0
        while not done:
            state, reward, done, _ = env.step(env.action_space.sample())
            steps += 1
        print(f'{i}, {time.time() - start_time}s, step: {steps}')



