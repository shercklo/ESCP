import os
from parameter.private_config import get_base_path
#print('cd {} && scp -rp *[!log_file] luofm@114.212.22.189:/home/luofm/Downloads/middle_server/ && scp -r .git luofm@114.212.22.189:/home/luofm/Downloads/middle_server/'.format(get_base_path()))
#os.system('cd {} && scp -rp *[!log_file] luofm@114.212.22.189:/home/luofm/Downloads/middle_server/ && scp -r .git luofm@114.212.22.189:/home/luofm/Downloads/middle_server/'.format(get_base_path()))
def system(cmd):
    print(cmd)
    os.system(cmd)
# print('ssh luofm@114.212.22.189 "bash /home/luofm/Downloads/middle_server/sync_code.sh"')
# os.system('ssh luofm@114.212.22.189 "bash /home/luofm/Downloads/middle_server/sync_code.sh"')
# system('ssh luofm@114.212.22.189 "bash /home/luofm/Downloads/middle_server/sync_code.sh"')
system('date')
system('ssh -p 6000 luofm@59.110.231.161 "bash /home/luofm/Downloads/middle_server_2/sync_code.sh"')