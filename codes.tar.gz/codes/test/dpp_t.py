from dppy.finite_dpps import FiniteDPP
import numpy as np
from utils.timer import Timer


class DPP:
    def __init__(self):
        self.dpp = None
        self.rank = 0

    def feed_data(self, x):
        x = np.array(x).reshape((-1, 1))
        r = np.max(x) - np.min(x)
        if r > 0:
            x = (x - np.min(x)) / r * np.pi
        PHI = np.hstack([np.cos(x), np.sin(x)]).reshape((-1, 2)).T
        L = PHI.T@PHI
        self.dpp = FiniteDPP('likelihood', L_gram_factor=PHI)

    def sample(self, num):
        inds = []
        for i in range(num):
            inds.extend(self.dpp.sample_exact())
            if len(inds) >= num:
                break
        self.dpp.flush_samples()
        return inds

    def info(self):
        if self.dpp is not None:
            self.dpp.info()

if __name__ == '__main__':
    timer = Timer()
    x = np.random.randn(2000, 1)
    timer.register_point()
    dpp = DPP()
    timer.register_point()
    dpp.feed_data(x)
    timer.register_point()
    inds = dpp.sample(100)
    timer.register_end()
    dpp.info()
    print(f'inds: {inds}\n')
    y = [x[ind] for ind in inds]
    print(y)
    print(timer.summary())

