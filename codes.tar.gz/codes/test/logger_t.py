import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from log_util.logger import Logger
import time
if __name__ == '__main__':
    logger = Logger()
    logger.log(122, '22', color='red', bold=False)
    data = {'a': 10, 'b': 11, 'c': 13}
    for i in range(10):
        for _ in range(10):
            for k in data:
                data[k] += 1
            logger.add_tabular_data(**data)
        logger.log_tabular('a')
        logger.dump_tabular()

