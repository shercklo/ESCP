import sys,os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import gym
gym.logger.set_level(40)
import numpy as np
from agent.Agent import EnvRemoteArray
from envs.nonstationary_env import NonstationaryEnv
from models.policy import Policy
from utils.replay_memory import Memory
from log_util.logger import Logger
import time
import ray
from threading import Thread
def func():
    for _ in range(100):
        time.sleep(1)


if __name__ == '__main__':
    env_name = 'Hopper-v2'
    env = NonstationaryEnv(gym.make(env_name))
    logger = Logger()
    parameter = logger.parameter
    ray.init()
    worker_num = 10
    env_array = EnvRemoteArray(parameter=parameter, env_name=env_name,
                               worker_num=worker_num, seed=None,
                               policy_type=Policy, env_decoration=NonstationaryEnv,
                               use_true_parameter=False,
                               env_tasks=env.sample_tasks(10), history_len=0, use_remote=True)
    configs = Policy.make_config_from_param(parameter)
    net = Policy(env.observation_space.shape[0], env.action_space.shape[0], **configs)
    import time
    total_step = 0
    replay_buffer = Memory()
    for _ in range(2):
        t0 = time.time()
        batch, logs, mem = env_array.collect_samples(40000, net, need_memory=True)
        logger.add_tabular_data(**logs)
        replay_buffer.append(mem)

        #for i in range(4000):
        #   mem, logs = env_array.sample1step(net, False)
        #   replay_buffer.append(mem)
        #   logger.add_tabular_data(**logs)

        total_step += 4000 * worker_num
        # transitions = env_array.extract_from_memory(memory)
        t1 = time.time()
        logger.log_tabular('TimeInterval (s)', t1-t0)
        logger.log_tabular('EnvSteps', total_step)
        logger.log_tabular('ReplayBufferSize', len(replay_buffer))
        logger.dump_tabular()
        # print(logs)

