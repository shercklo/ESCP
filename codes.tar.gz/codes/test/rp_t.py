import os, sys
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from parameter.private_config import *

from utils.replay_memory import Memory, MemoryNp

# docker run --rm -it --shm-size 50gb -v $PWD:/root/workspace sanluosizhou/selfdl:latest -c "export CUDA_VISIBLE_DEVICES=1 && python /root/workspace/test/rp_t.py"

if __name__ == '__main__':
    replay_buffer = MemoryNp(False, 16)
    replay_buffer.set_max_size(1e6)
    replay_buffer_dir = os.path.join(get_base_path(), 'log_file', 'HalfCheetah-v2-ep_dim_16-8', 'replay_buffer.pkl')
    replay_buffer.load_from_disk(replay_buffer_dir)
    all_trasitions = replay_buffer.sample_transitions()
    print(len(all_trasitions), replay_buffer.size, len(replay_buffer),
          len(all_trasitions.state), len(all_trasitions.task),
          len(all_trasitions.env_param))
    task = all_trasitions.task
    env_param = all_trasitions.env_param
    for _task, _env_param in zip(task, env_param):
        print(_task[0], list(_env_param))