from models.rnn_base import RNNBase
from models.policy import Policy
import torch


class Trainsition(Policy):
    def __init__(self, obs_dim, act_dim, up_hidden_size, up_activations, up_layer_type,
                 ep_hidden_size, ep_activation, ep_layer_type, ep_dim, use_gt_env_feature,
                 rnn_fix_length, use_vrdc, share_ep,
                 logger=None, freeze_ep=False, enhance_ep=False, stop_pg_for_ep=False,
                 bottle_neck=False, bottle_sigma=1e-4):
        super(Policy, self).__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.use_gt_env_feature = use_gt_env_feature
        # stop the gradient from ep when inferring action.
        self.stop_pg_for_ep = stop_pg_for_ep
        self.enhance_ep = enhance_ep
        self.bottle_neck = bottle_neck
        self.bottle_sigma = bottle_sigma
        # aux dim: we add ep to every layer inputs.
        aux_dim = ep_dim if enhance_ep else 0
        self.up = RNNBase(obs_dim + act_dim + ep_dim, obs_dim, up_hidden_size, up_activations, up_layer_type, logger, aux_dim)
        self.ep = RNNBase(obs_dim + act_dim, ep_dim, ep_hidden_size, ep_activation, ep_layer_type, logger)
        self.ep_temp = RNNBase(obs_dim + act_dim, ep_dim, ep_hidden_size, ep_activation, ep_layer_type, logger)
        self.ep_rnn_count = self.ep.rnn_num
        self.up_rnn_count = self.up.rnn_num
        # ep first, up second
        self.module_list = torch.nn.ModuleList(self.up.total_module_list + self.ep.total_module_list
                                               + self.ep_temp.total_module_list)
        self.min_log_std = -7.0
        self.max_log_std = 2.0
        self.sample_hidden_state = None
        self.rnn_fix_length = rnn_fix_length
        self.use_vrdc = use_vrdc
        self.ep_tensor = None
        self.share_ep = share_ep
        self.freeze_ep = freeze_ep
        self.allow_sample = True


    def meta_forward(self, x, action, lst_a, h, require_full_output=False):
        ep_h = h[:self.ep_rnn_count]
        up_h = h[self.ep_rnn_count:]
        if not require_full_output:
            if not self.use_gt_env_feature:
                ep, ep_h_out = self.get_ep(torch.cat((x, lst_a), -1), ep_h)
                if self.bottle_neck and self.allow_sample:
                    ep = ep + torch.randn_like(ep) * self.bottle_sigma
                if self.stop_pg_for_ep:
                    ep = ep.detach()
                aux_input = ep if self.enhance_ep else None
                up, up_h_out = self.up.meta_forward(torch.cat((x, action, ep), -1), up_h, aux_state=aux_input)
            else:
                up, up_h_out = self.up.meta_forward(torch.cat((x, action), dim=-1), up_h)
                ep_h_out = []
        else:
            if not self.use_gt_env_feature:
                ep, ep_h_out, ep_full_hidden = self.get_ep(torch.cat((x, lst_a), -1), ep_h, require_full_output)
                if self.bottle_neck and self.allow_sample:
                    ep = ep + torch.randn_like(ep) * self.bottle_sigma
                if self.stop_pg_for_ep:
                    ep = ep.detach()
                aux_input = ep if self.enhance_ep else None
                up, up_h_out, up_full_hidden = self.up.meta_forward(torch.cat((x, action, ep), -1), up_h, require_full_output, aux_state=aux_input)
            else:
                up, up_h_out, up_full_hidden = self.up.meta_forward(torch.cat((x, action), dim=-1), up_h, require_full_output)
                ep_h_out = []
                ep_full_hidden = []
            h_out = ep_h_out + up_h_out
            return up, h_out, ep_full_hidden + up_full_hidden
        h_out = ep_h_out + up_h_out
        return up, h_out

    def forward(self, x, action, lst_a, h):
        mu, h_out = self.meta_forward(x, action, lst_a, h)
        return mu, None, h_out

    def rsample(self, x, action, lst_a, h):
        mu, _, h_out = self.forward(x, action, lst_a, h)
        mu = torch.tanh(mu) * 10 + x
        return mu, None, mu, None, h_out