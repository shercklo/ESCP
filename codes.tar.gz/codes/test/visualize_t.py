import sys, os
import numpy as np
import random
import torch
import gym
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from parameter.private_config import *
from parameter.Parameter import Parameter
from agent.Agent import EnvRemoteArray
from envs.nonstationary_env import NonstationaryEnv
from models.policy import Policy
import matplotlib.pyplot as plt
def make_log_paths(env_name):
    return {
      #   f'{env_name}-{32}': f'/Users/fanmingluo/Desktop/record_0626/vrdc_32/{env_name}-use_vrdc-rnn_len_32-stop_pg_for_ep-ep_dim_2-5_NEW_ENV_VRDC',
      #   f'{env}-{16}': f'/Users/fanmingluo/Desktop/record_0626/vrdc_16/{env}-use_vrdc-rnn_len_16-stop_pg_for_ep-ep_dim_2-5_NEW_ENV_VRDC_16_len',
      #   f'{env_name}-{8}': f'/Users/fanmingluo/Desktop/record_0626/vrdc_8/{env_name}-use_vrdc-rnn_len_8-stop_pg_for_ep-ep_dim_2-5_NEW_ENV_VRDC_8_len',
      #   f'{env_name}-{4}': f'/Users/fanmingluo/Desktop/record_0626/vrdc_4/{env_name}-use_vrdc-rnn_len_4-stop_pg_for_ep-ep_dim_2-6_NEW_ENV_VRDC_4_len',
      #   f'{env_name}-{2}': f'/Users/fanmingluo/Desktop/record_0626/vrdc_2/{env_name}-use_vrdc-rnn_len_2-stop_pg_for_ep-ep_dim_2-6_NEW_ENV_VRDC_2_len',
      # f'baselines': f'/Users/fanmingluo/Desktop/record_0626/baselines/{env_name}-ep_dim_2-6_NEW_ENV_BL_FIX_BUG',
        f'{env_name}-bl': f'/Users/fanmingluo/Code/py/modified_policy_adapatation/log_file/GridWorldNS-v2-ep_dim_2-5_NEW_ENV_BASELINE',
        f'{env_name}-{8}': f'/Users/fanmingluo/Code/py/modified_policy_adapatation/log_file/GridWorldNS-v2-use_vrdc-rnn_len_8-stop_pg_for_ep-ep_dim_2-5_large_radius'
        # 'fix_length_bl': f'/Users/fanmingluo/Desktop/record_0626/fix_length_bl/{env_name}-rnn_len_32-ep_dim_2-6_NEW_ENV_FIX_LENGTH_BL',
    }

# docker run --rm -it --shm-size 50gb -v $PWD:/root/workspace sanluosizhou/selfdl:robosumo -c "export CUDA_VISIBLE_DEVICES=1 && python /root/workspace/test/visualize_t.py"

def global_seed(*args, seed):
    for item in args:
        item.seed(seed)

def make_policy_agent_from_config(parameter, task_path):
    ns_env = NonstationaryEnv(gym.make(parameter.env_name), log_scale_limit=ENV_DEFAULT_CHANGE,
                              rand_params=parameter.varying_params)
    global_seed(np.random, random, ns_env, seed=parameter.seed)
    torch.manual_seed(parameter.seed)
    tasks = ns_env.sample_tasks(40)
    # print(ns_env.observation_space, ns_env.action_space)
    # print(parameter)
    agent = EnvRemoteArray(parameter=parameter, env_name=parameter.env_name,
                           worker_num=1, seed=parameter.seed,
                           deterministic=False, use_remote=False, policy_type=Policy,
                           history_len=parameter.history_length, env_decoration=NonstationaryEnv,
                           env_tasks=tasks,
                           use_true_parameter=False,
                           non_stationary=True)
    policy_config = Policy.make_config_from_param(parameter)
    policy = Policy(agent.obs_dim, agent.act_dim, **policy_config)
    policy.load(os.path.join(task_path, 'model'), map_location=torch.device('cpu'))
    return agent, policy

def get_figure(policy, agent, step_num, title=''):
    # fig = plt.figure(2)
    ep_traj = []
    real_param = []
    for i in range(step_num):
        mem, log = agent.sample1step1env(policy, False, render=False)
        real_param.append(mem.memory[0].env_param)
        # print(policy.ep_tensor.shape)
        ep_traj.append(policy.ep_tensor[:1, ...].squeeze().detach().cpu().numpy())
    ep_traj = np.array(ep_traj)
    real_param = np.array(real_param)
    change_inds = np.where(np.abs(np.diff(real_param[:, -1])) > 0)[0] + 1
    # print(np.hstack((ep_traj, real_param)))
    plt.plot(ep_traj[:, 0], label='x')
    plt.plot(ep_traj[:, 1], label='y')
    plt.plot(real_param[:, -1], label='real')
    for ind in change_inds:
        plt.plot([ind, ind], [-1.1, 1.1], 'k--', alpha=0.2)
    plt.ylim(bottom=-1.1, top=1.1)
    plt.legend()
    plt.title(title)
    # return fig

def identity_test(agent, policy, parameter):
    policy.inference_init_hidden(1, torch.device('cpu'))
    state = torch.from_numpy(np.random.randn(parameter.rnn_fix_length, agent.env.observation_space.shape[0])).to(torch.get_default_dtype())
    last_action = torch.from_numpy(np.random.randn(parameter.rnn_fix_length, agent.env.action_space.shape[0])).to(torch.get_default_dtype())
    h_in = policy.make_init_state(1, device=torch.device('cpu'))

    mu, std, _, _, h_out = policy.rsample(state.unsqueeze(0), last_action.unsqueeze(0), h_in,)
    mu_list = []
    for i in range(state.shape[0]):
        mu_, std, _, _, h_in = policy.rsample(state[i:i+1].unsqueeze(0), last_action[i:i+1].unsqueeze(0), h_in, )
        mu_list.append(mu_[0])
    mu_list = torch.cat(mu_list, dim=0)
    actions = []
    for i in range(state.shape[0]):
        # print(policy.sample_hidden_state)
        action_ = policy.inference_one_step(torch.cat((last_action[i:i+1, :], state[i:i+1, :]), -1), deterministic=True)
        actions.append(action_)
    print((mu - torch.cat(actions, dim=0)).pow(2).sum(dim=-1, keepdim=True).sqrt())
    print((mu - mu_list).pow(2).sum(dim=-1, keepdim=True).sqrt())
    # print(mu, torch.cat(actions, dim=0))

def main(env_name='Hopper-v2', ind=0):
    plt.figure(ind)
    log_paths = make_log_paths(env_name)
    print('start visualizing!!!!')
    for ind, (short_name, path) in enumerate(log_paths.items()):
        parameter = Parameter(config_path=path)
        agent, policy = make_policy_agent_from_config(parameter, path)
        print('start sampling...')
        plt.subplot(int(f'23{ind+1}'))
        fig = get_figure(policy, agent, 1000, short_name)
        # identity_test(agent, policy, parameter)
        print('done')
    # plt.show()
    save_path = '/Users/fanmingluo/Desktop/record_0626/pic/BEHAVIOUR'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    plt.savefig(os.path.join(save_path, '{}.pdf'.format(env_name)))

    pass

if __name__ == '__main__':
    for ind, env in enumerate(
            # ['Hopper-v2',
            #     'HalfCheetah-v2',
            #     'Walker2d-v2',
            #     'Ant-v2',
            #     'Humanoid-v2']
        ['GridWorldNS-v2']
                              ):
        main(env, ind)