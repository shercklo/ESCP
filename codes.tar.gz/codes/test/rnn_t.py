import sys,os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.policy import Policy
from parameter.Parameter import Parameter
from parameter.private_config import *
import torch


if __name__ == '__main__':
    parameter = Parameter()
    policy_config = Policy.make_config_from_param(parameter)
    input_len = 4
    output_len = 2
    slice_num = 10
    seq_num = 3
    seq_len = 80
    policy = Policy(input_len, output_len, **policy_config)

    inputs1 = torch.randn((seq_num, seq_len, input_len))
    inputs2 = torch.randn((seq_num, seq_len, output_len))
    initial_hidden = policy.make_init_state(inputs1.shape[0], device=inputs1.device)
    mu, std, sample, log_prob, h_out = policy.rsample(inputs1, inputs2, initial_hidden)
    hidden_total = policy.generate_hidden_state(inputs1, inputs2, slice_num)
    inputs1_sliced, inputs2_sliced = map(Policy.slice_tensor, [inputs1, inputs2], [slice_num] * 2)
    inputs1_sliced, inputs2_sliced = Policy.merge_slice_tensor(inputs1_sliced, inputs2_sliced)
    # print(inputs1_sliced, '\n\n\n', inputs1)
    # hidden_total = policy.make_init_state(inputs1_sliced.shape[0], device=inputs1.device)
    mu_sliced, std_slice, _, _, _ = policy.rsample(inputs1_sliced, inputs2_sliced, hidden_total)
    print(mu, '\n\n', mu_sliced)
