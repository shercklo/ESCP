import argparse
import yaml
from parameter.private_config import *

# template = "vdfe &&sleep {0} && export CUDA_VISIBLE_DEVICES={1} && cd SLBDAO/dfe_sac/src && python main.py --seed {2} --env_id {4} --info {5} --anchor_state_size {6} --preserve_ratio {7} "
config = {"session_name": "run-all-8829-baseline", "windows": []}
base_path = get_base_path()
docker_path = "/root/policy_adaptation"
path = docker_path
tb_port = 6006
docker_template = f'docker run --rm -it --shm-size 50gb -v {base_path}:{docker_path} sanluosizhou/selfdl:latest -c '
docker_template_port = f'docker run --rm -it --shm-size 50gb -v {base_path}:{docker_path} -p 6006:{tb_port} sanluosizhou/selfdl:latest -c '
template = 'export CUDA_VISIBLE_DEVICES={0} && cd {1} ' \
           '&& python main.py --env_name {3} --history_length {4} --seed {5} ' \
           ' --task_num {6} --num_threads {7} --vrdc_update_interval {9} --vrdc_ratio {10} ' \
           ' --imitate_update_interval {11} --mi_ratio {12} --max_iter_num {13} ' \
           '--varying_params {14} --rnn_slice_num {15} --rnn_fix_length {16} --test_task_num {17} ' \
           '--sac_mini_batch_size {18} --ep_dim {19} --ep_pretrain_path_suffix \"{20}\" ' \
           ' --bottle_sigma {21} --policy_max_gradient {22} --l2_norm_for_ep {23} --minimal_repre_rp_size {24} ' \
           ' --repre_loss_factor {25} --ep_smooth_factor {26} --name_suffix {27} '
template2 = docker_template_port + '"sleep 25 && cd {0} && tensorboard --logdir=./log_file"'
template3 = docker_template + '"cd {0}"'
seeds = [2]
GPUS = [0, 1]
rnn_slice_num = 16
envs = ['HalfCheetah-v2', 'Hopper-v2', 'Walker2d-v2']
# envs = ['Hopper-v2']
# envs = ['HalfCheetah-v2']
count_it = 0
algs = ['sac']
num_thread = 4
task_common_num = 40
common_hist_num = 0
mutual_information_ratio = 0.1
max_iter_num = 2000
uniform_sample_from_rb = False
rnn_fix_length = 32
test_task_num = 40
minimal_repre_rp_size = 0
share_ep = False
ep_dim = 2
enhance_ep = False
stop_pg_for_ep = False
use_bottleneck = False
bottle_sigma = 0.0
policy_max_gradient = 10
l2_norm_for_ep = 1e-3
repre_loss_factor = 0.1
ep_smooth_factor = 0.0
ep_pretrain_path_suffix = 'None' # 'use_vrdc-rnn_len_32-ep_dim_2-111-debug_NJ' # 'None'
if rnn_fix_length == 0:
    sac_mini_batch_size = 512
else:
    sac_mini_batch_size = 512
varying_params = [
    ' gravity ',
]


vrdc_ratio = 1.0   # hist,    task_num,                 param, VRDC, mutual_information, vrc_only, uposi, vrdc-update-interva;
hist_and_taks_num = [
    [common_hist_num, task_common_num, False, False, False, False, False, -1, False, 2, 0, 'BASELINE_FULL'],  # value regression only
    [common_hist_num, task_common_num, False, False, False, False, False, -1, False, 2, 32, 'BASELINE_FIXLENGTH'],
    # value regression only

]
# vrdc_update_interval = 100
imitate_update_interval = 50
for seed in seeds:
    for env in envs:
        panes_list = []
        for varying_param in varying_params:
            for alg in algs:
                for hist, task_num, use_true_parameter, use_vrdc, use_mutual, vrc_only, use_uposi, vrdc_update_interval, share_ep, ep_dim, rnn_fix_length, name_suffix in hist_and_taks_num:
                    if rnn_fix_length == 0:
                        sac_mini_batch_size = 512
                    else:
                        sac_mini_batch_size = 512
                    count_it = count_it + 1
                    script_it = template.format(GPUS[count_it % len(GPUS)], path, alg, env, hist, seed, task_num,
                                                num_thread, count_it*10, vrdc_update_interval, vrdc_ratio,
                                                imitate_update_interval, mutual_information_ratio, max_iter_num,
                                                varying_param, rnn_slice_num, rnn_fix_length, test_task_num,
                                                sac_mini_batch_size, ep_dim, ep_pretrain_path_suffix, bottle_sigma,
                                                policy_max_gradient, l2_norm_for_ep, minimal_repre_rp_size,
                                                repre_loss_factor, ep_smooth_factor, name_suffix)
                    if use_true_parameter:
                        script_it += ' --use_true_parameter '
                    if use_vrdc:
                        script_it += ' --use_vrdc '
                    if use_mutual:
                        script_it += ' --use_mutual_information '
                    if vrc_only:
                        script_it += ' --vrc_only '
                    if use_uposi:
                        script_it += ' --use_uposi '
                    if uniform_sample_from_rb:
                        script_it += ' --uniform_sample '
                    if share_ep:
                        script_it += ' --share_ep '
                    if enhance_ep:
                        script_it += ' --enhance_ep '
                    if stop_pg_for_ep:
                        script_it += ' --stop_pg_for_ep '
                    if use_bottleneck:
                        script_it += ' --bottle_neck '
                    script_it = docker_template + '"{}"'.format(script_it)
                    print('{}-{}'.format(env, seed), ': ', script_it)

                    panes_list.append(script_it)
        config["windows"].append({
            "window_name": "{}-{}".format(env, seed),
            "panes": panes_list,
            "layout": "tiled"
        })

config["windows"].append({
        "window_name": "tensorboard",
        "panes": [template2.format(path)],
        "layout": "tiled"
    })
print(template2.format(path))

config["windows"].append({
        "window_name": "init_operation",
        "panes": [template3.format(path)],
        "layout": "tiled"
    })
print(template3.format(path))
yaml.dump(config, open("run_all.yaml", "w"), default_flow_style=False)
