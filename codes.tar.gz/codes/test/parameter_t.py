import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from parameter.Parameter import Parameter
import time

if __name__ == '__main__':
    parameter = Parameter()
    commit_id = parameter.get_commit_id()
    time.sleep(3)
    parameter2 = Parameter()
    print(parameter)
    parameter.save_config()
    parameter.gamma = 1.0
    identity_flag = parameter.check_identity(need_decription=True)
    parameter.load_config()
    identity_flag2 = parameter.check_identity(need_decription=True)
    identity_flag3 = parameter2.check_identity(need_exec_time=True)
    identity_flag4 = parameter2.check_identity(need_decription=True)
    print(parameter)
    parameter.clear_local_file()
    print(f'identity check flag: {identity_flag}, {identity_flag2}, {identity_flag3}, {identity_flag4}')
    print(f'{__file__} 结尾 \n\n')
