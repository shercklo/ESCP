import torch


def main():
    pass

def get_rbf_matrix_pre(data, centers, alpha):
    out_shape = torch.Size([data.shape[0], centers.shape[0], data.shape[-1]])
    data = data.unsqueeze(1).expand(out_shape)
    centers = centers.unsqueeze(0).expand(out_shape)
    mtx = (-(centers - data).pow(2) * alpha).exp().sum(dim=-1, keepdim=False)
    return mtx



if __name__ == '__main__':
    feature_dim = 1
    feature_num = 5
    center_num = 2
    data = torch.randn((feature_num, feature_dim))
    centers = data  # torch.randn((center_num, feature_dim))
    rbf_mtx = get_rbf_matrix_pre(data, data, 1.0)
    print(data)
    print(rbf_mtx)

