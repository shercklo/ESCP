import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from log_util.logger import Logger

if __name__ == '__main__':
    logger = Logger()
    if logger.log_file:

        sys.stdout = logger.log_file
        sys.stderr = logger.log_file
        assert False, '1234'
        # print('1,2,3')
