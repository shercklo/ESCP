import tensorflow as tf
import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from log_util.logger import Logger
from models.policy import Policy
from models.value import Value
from parameter.private_config import *
from agent.Agent import EnvRemoteArray
from envs.nonstationary_env import NonstationaryEnv
from utils.replay_memory import Memory, MemoryNp
import gym
import robosumo.envs
import torch
import numpy as np
import random
from utils.torch_utils import to_device
import time
from utils.timer import Timer
from collections import deque
import math


class SAC:
    def __init__(self):
        self.logger = Logger()
        # self.logger.set_tb_x_label('TotalInteraction')
        self.timer = Timer()
        self.parameter = self.logger.parameter
        self.policy_config = Policy.make_config_from_param(self.parameter)
        self.value_config = Value.make_config_from_param(self.parameter)
        self.env = NonstationaryEnv(gym.make(self.parameter.env_name), log_scale_limit=ENV_DEFAULT_CHANGE,
                                    agent_name=self.parameter.env_name.split('-')[3].lower(), id='sac')
        self.global_seed(np.random, random, self.env, seed=self.parameter.seed)
        torch.manual_seed(seed=self.parameter.seed)
        self.env_tasks = self.env.sample_tasks(self.parameter.task_num)
        self.freeze_eta_r = True
        self.training_agent = EnvRemoteArray(parameter=self.parameter, env_name=self.parameter.env_name,
                                             worker_num=1, seed=self.parameter.seed,
                                             deterministic=False, use_remote=False, policy_type=Policy,
                                             history_len=self.parameter.history_length, env_decoration=NonstationaryEnv,
                                             env_tasks=self.env_tasks,
                                             use_true_parameter=self.parameter.use_true_parameter,
                                             non_stationary=False)

        self.test_agent = EnvRemoteArray(parameter=self.parameter, env_name=self.parameter.env_name,
                                         worker_num=self.parameter.num_threads, seed=self.parameter.seed + 1,
                                         deterministic=True, use_remote=True, policy_type=Policy,
                                         history_len=self.parameter.history_length, env_decoration=NonstationaryEnv,
                                         env_tasks=self.env_tasks,
                                         use_true_parameter=self.parameter.use_true_parameter,
                                         non_stationary=False)

        if self.parameter.use_true_parameter:
            self.policy_config['ep_dim'] = self.training_agent.env_parameter_len
            self.value_config['ep_dim'] = self.training_agent.env_parameter_len
        self.policy_config['logger'] = self.logger
        self.value_config['logger'] = self.logger
        self.obs_dim = self.training_agent.obs_dim
        self.act_dim = self.training_agent.act_dim
        self.policy = Policy(self.training_agent.obs_dim, self.training_agent.act_dim, **self.policy_config)
        print(f'input size of policy UP: {self.policy.up.input_size}')
        self.value1 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.value2 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.target_value1 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.target_value2 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        self.tau = self.parameter.sac_tau
        self.target_entropy = -self.parameter.target_entropy_ratio * self.act_dim
        self.replay_buffer = Memory()
        self.replay_buffer.set_max_size(self.parameter.sac_replay_size)
        self.eta_r = 1.0
        self.policy_optimizer = torch.optim.Adam(self.policy.parameters(True), lr=self.parameter.learning_rate / self.eta_r)
        self.value_optimizer = torch.optim.Adam([*self.value1.parameters(True)] + [*self.value2.parameters(True)],
                                                lr=self.parameter.value_learning_rate)
        self.device = torch.device('cuda', index=0) if torch.cuda.is_available() else torch.device('cpu')
        self.logger.log(f"torch device is {self.device}")
        self.log_sac_alpha = (torch.ones((1)).to(torch.get_default_dtype()
                                         ) * np.log(self.parameter.sac_alpha)).to(self.device).requires_grad_(True)
        self.alpha_optimizer = torch.optim.Adam([self.log_sac_alpha], lr=1e-2)
        self.log_eta = (torch.ones((1)).to(torch.get_default_dtype()) * (np.log(self.parameter.regret_eta
                                                                            ))).to(self.device).requires_grad_(True)

        self.eta_star = 1.0
        self.r = 1
        self.Br = 1.0
        self.alpha_r = float(self.training_agent.act_dim)
        self.last_Q_mean = None
        self.cum_error = 0.0
        self.eta_optimizer = torch.optim.Adam([self.log_eta], lr=1e-2)
        to_device(self.device, self.policy, self.value1, self.value2, self.target_value1, self.target_value2)
        self.policy_queue = deque(maxlen=1)
        self.value_queue = deque(maxlen=1)

        self.update_policy_queue()
        self.global_iteration = 0
        self.logger.register_keys(['CriticLoss', 'ActorLoss', 'Alpha', 'QMean1',
                                   'QMean2', 'Logp', 'period_self.update', 'period_self.sac_update',
                                   'period_sample_from_replay', 'OldLogp', 'KL', 'eta', 'HedgeR', 'HedgeBr',
                                   'HedgeEtar', 'EtaLoss', 'AlphaLoss', 'EntDisp', 'MuL1Norm', 'MuL2Norm'])

    @staticmethod
    def global_seed(*args, seed):
        for item in args:
            item.seed(seed)

    def update_eta_r(self, Q_current):
        if self.last_Q_mean is not None:
            self.cum_error = (Q_current - self.last_Q_mean)**2
        if self.cum_error >= self.Br:
            self.r += 1
            self.Br = self.Br * 2
            if not self.freeze_eta_r:
                self.eta_r = min(self.eta_star, self.alpha_r / math.sqrt(self.Br))
        self.last_Q_mean = Q_current

    def update_policy_queue(self):
        policy = Policy(self.training_agent.obs_dim, self.training_agent.act_dim, **self.policy_config)
        policy.to(self.device)
        policy.copy_weight_from(self.policy, 0)
        self.policy_queue.append(policy)

        value1 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        value1.to(self.device)
        value1.copy_weight_from(self.value1, 0)
        value2 = Value(self.training_agent.obs_dim, self.training_agent.act_dim, **self.value_config)
        value2.to(self.device)
        value2.copy_weight_from(self.value2, 0)

        self.value_queue.append([value1, value2])

    def sac_update_origin(self, state, action, next_state, reward, mask, last_action):
        """reward, mask should be (-1, 1)"""
        if len(reward.shape) == 1:
            reward = torch.reshape(reward, (-1, 1))
        if len(mask.shape) == 1:
            mask = torch.reshape(mask, (-1, 1))
        alpha = self.log_sac_alpha.exp()
        hidden_state = []
        hidden_state_value = []
        if not FC_MODE:
            hidden_state = self.policy.make_init_state(state.shape[0], device=self.device)
            hidden_state_value = self.value1.make_init_state(state.shape[0], device=self.device)
        """update critic/value net"""
        with torch.no_grad():
            _, _, next_action_total, next_logp_total, _ = self.policy.rsample(next_state, hidden_state)
            target_Q1, _ = self.target_value1.forward(next_state, next_action_total, hidden_state_value)
            target_Q2, _ = self.target_value2.forward(next_state, next_action_total, hidden_state_value)
            nextact_logprob = next_logp_total
            target_v = torch.min(target_Q1, target_Q2) - alpha.detach() * nextact_logprob
            target_Q = (reward + (mask * self.parameter.gamma * target_v)).detach()
        current_Q1, _ = self.value1.forward(state, action, hidden_state_value)
        current_Q2, _ = self.value2.forward(state, action, hidden_state_value)
        critic_loss = (current_Q1 - target_Q).pow(2).mean() + (current_Q2 - target_Q).pow(2).mean()
        self.value_optimizer.zero_grad()
        critic_loss.backward()
        self.value_optimizer.step()
        """update policy and alpha"""
        _, _, action_rsample, logprob, _ = self.policy.rsample(state, hidden_state)
        actor_q1, _ = self.value1.forward(state, action_rsample, hidden_state_value)
        actor_q2, _ = self.value2.forward(state, action_rsample, hidden_state_value)
        actor_q = torch.min(actor_q1, actor_q2)
        actor_loss = (alpha.detach() * logprob - actor_q).mean()
        self.policy_optimizer.zero_grad()
        actor_loss.backward()
        self.policy_optimizer.step()

        alpha_loss = - (alpha * (logprob + self.target_entropy).detach()).mean()
        self.alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.alpha_optimizer.step()
        with torch.no_grad():
            self.log_sac_alpha.clamp_max_(0)
        self.value_function_soft_update()
        q_mean1 = actor_q1.mean().item()
        q_mean2 = actor_q2.mean().item()
        logp_pi = logprob.mean().item()
        return dict(
            CriticLoss=critic_loss.item(),
            ActorLoss=actor_loss.item(),
            Alpha=alpha.item(),
            QMean1=q_mean1,
            QMean2=q_mean2,
            Logp=logp_pi
        )


    # adapt for regret optimization: requiring the old policy model when updating...
    def sac_update(self, state, action, next_state, reward, mask, last_action):
        """reward, mask should be (-1, 1)"""
        if len(reward.shape) == 1:
            reward = torch.reshape(reward, (-1, 1))
        if len(mask.shape) == 1:
            mask = torch.reshape(mask, (-1, 1))
        alpha = self.log_sac_alpha.exp()
        regret_eta = (self.log_eta).exp()
        hidden_state = []
        hidden_state_value = []
        if not FC_MODE:
            hidden_state = self.policy.make_init_state(state.shape[0], device=self.device)
            hidden_state_value = self.value1.make_init_state(state.shape[0], device=self.device)
        """update critic/value net"""
        with torch.no_grad():
            _, _, next_action_total, next_logp_total, _ = self.policy.rsample(next_state, hidden_state)
            target_Q1, _ = self.target_value1.forward(next_state, next_action_total, hidden_state_value)
            target_Q2, _ = self.target_value2.forward(next_state, next_action_total, hidden_state_value)
            target_Q1, target_Q2, nextact_logprob = target_Q1, target_Q2, next_logp_total
            # adapt for regret optimization: drop away the logprob in target v
            target_v = torch.min(target_Q1, target_Q2)   # - alpha.detach() * nextact_logprob
            target_Q = (reward + (mask * self.parameter.gamma * target_v)).detach()
        current_Q1, _ = self.value1.forward(state, action, hidden_state_value)
        current_Q2, _ = self.value2.forward(state, action, hidden_state_value)
        critic_loss = (current_Q1 - target_Q).pow(2).mean() + (current_Q2 - target_Q).pow(2).mean()
        # critic_loss = (current_Q1 - 1).pow(2).mean() + (current_Q2 - 1).pow(2).mean()

        self.value_optimizer.zero_grad()
        critic_loss.backward()
        self.value_optimizer.step()
        """update policy and alpha"""
        mu, _, action_rsample, logprob, origin_sample, _ = self.policy.rsample(state, hidden_state,
                                                                              need_original_sample=True)
        old_dist, old_mu, _, _ = self.policy_queue[0].get_dist(state, hidden_state)
        old_mu = torch.tanh(old_mu)
        old_log_prob = self.policy_queue[0].get_logp(origin_sample, old_dist)
        actor_q1, _ = self.value1.forward(state, action_rsample, hidden_state_value)
        actor_q2, _ = self.value2.forward(state, action_rsample, hidden_state_value)
        actor_q = torch.min(actor_q1, actor_q2)
        if len(self.value_queue) > 0 and 0 < -1:
            last_value1, last_value2 = self.value_queue[0][0], self.value_queue[0][1]
            lst_actor_q1, _ = last_value1.forward(state, action_rsample, hidden_state_value)
            lst_actor_q2, _ = last_value2.forward(state, action_rsample, hidden_state_value)
            lst_actor_q = torch.min(lst_actor_q1, lst_actor_q2)
        else:
            # self.logger.log('value queue is empty...')
            lst_actor_q = torch.zeros_like(actor_q).detach()
        # adapt for regret optimization: change the loss
        lst_actor_q = actor_q
        policy_kl_loss = (logprob - old_log_prob.detach()) # (mu - old_mu).pow(2).mean().sqrt()
        mu_l1_norm = (mu - old_mu.detach()).abs().sum(-1, keepdim=True).mean()
        mu_l2_norm = (mu - old_mu.detach()).pow(2).sum(-1, keepdim=True).mean().sqrt()
        distance_metric = mu_l1_norm
        policy_q_loss = actor_q
        policy_entropy_loss = -logprob
        if regret_eta.item() < 1.0:
            actor_loss = (-policy_q_loss + regret_eta.detach() * distance_metric - policy_entropy_loss * alpha.detach()).mean()
        else:
            actor_loss = (- 1 / regret_eta.detach() * policy_q_loss + distance_metric -
                          1 / regret_eta.detach() * policy_entropy_loss * alpha.detach()).mean()

        max_discrepency = 1.0
        entropy_descripency = (logprob.mean() + self.target_entropy).pow(2).detach().sqrt().item()
        # print(f'entropy descripency: {entropy_descripency}, regret eta: {regret_eta.item()}, l2norm: {mu_l2_norm}')
        if entropy_descripency >= max_discrepency and self.global_iteration > 3:
            actor_loss = (
                        -policy_q_loss - policy_entropy_loss * alpha.detach()).mean()
        self.policy_optimizer.zero_grad()
        if torch.any(torch.isnan(actor_loss)):
            print('nan occurs in actor loss')
        # print(f'{actor_loss.mean().item()}, {policy_q_loss.mean().item()}, {policy_entropy_loss.mean().item()}, {distance_metric.mean().item()}')
        actor_loss.backward()
        self.policy_optimizer.step()

        # adapt for regret optimization: remove the alpha optimization.
        alpha_loss = - (alpha * (logprob + self.target_entropy).detach()).mean()
        self.alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.alpha_optimizer.step()
        # never adapt eta by gradient.
        # if not self.parameter.use_constant_eta:
        eta_loss_log = 0.0
        if entropy_descripency < max_discrepency:
            eta_loss = (regret_eta * (self.parameter.target_kl_regret - distance_metric).detach()).mean()
            self.eta_optimizer.zero_grad()
            eta_loss.backward()
            self.eta_optimizer.step()
            eta_loss_log = eta_loss.item()

        with torch.no_grad():
            self.log_sac_alpha.clamp_max_(0)
            self.log_eta.clamp_max_(4)
            self.log_eta.clamp_min_(-4)
        self.value_function_soft_update()
        q_mean1 = actor_q1.mean().item()
        q_mean2 = actor_q2.mean().item()
        logp_pi = logprob.mean().item()
        old_logp_pi = old_log_prob.mean().item()
        kl = (logprob - old_log_prob).mean().item()
        return dict(
            CriticLoss=critic_loss.item(),
            ActorLoss=actor_loss.item(),
            Alpha=alpha.item(),
            QMean1=q_mean1,
            QMean2=q_mean2,
            Logp=logp_pi,
            OldLogp=old_logp_pi,
            KL=kl,
            eta=self.log_eta.exp().item(),
            EtaLoss=eta_loss_log,
            AlphaLoss=alpha_loss.item(),
            EntDisp=entropy_descripency,
            MuL1Norm=mu_l1_norm.item(),
            MuL2Norm=mu_l2_norm.item()
        )

    def sac_update_from_buffer(self, origin_sac=True):
        log = {}
        sac_update = self.sac_update_origin if origin_sac else self.sac_update
        for _ in range(self.parameter.update_interval):
            self.timer.register_point('sample_from_replay', level=1)
            if FC_MODE:
                batch = self.replay_buffer.sample_transitions(self.parameter.sac_mini_batch_size)
            else:
                batch = self.replay_buffer.sample(self.parameter.sac_mini_batch_size)
            dtype = torch.get_default_dtype()
            device = self.device
            # self.logger(np.array(batch.state), np.array(batch.reward))
            states, next_states, actions, last_action, rewards, masks = \
                map(lambda x: torch.from_numpy(np.array(x)).to(dtype=dtype, device=device), [
                    batch.state, batch.next_state, batch.action, batch.last_action, batch.reward, batch.mask
            ])
            self.timer.register_end(level=1)
            if len(rewards.shape) == 1 and FC_MODE:
                rewards = torch.reshape(rewards, (-1, 1))
            #if custom_additional_reward is not None:
            #    with torch.no_grad():
            #        rewards = rewards + custom_additional_reward(states)
            with torch.set_grad_enabled(True):
                self.timer.register_point('self.sac_update', level=1)
                res_dict = sac_update(states, actions, next_states, rewards, masks, last_action)
                self.timer.register_end(level=1)
                for key in res_dict:
                    if key in log:
                        log[key].append(res_dict[key])
                    else:
                        log[key] = [res_dict[key]]
        return log

    def update(self):
        log = self.sac_update_from_buffer(origin_sac=self.parameter.baseline_sac)

        return log

    @staticmethod
    def append_key(d, tail):
        res = {}
        for k, v in d.items():
            res[k+tail] = v
        return res

    def value_function_soft_update(self):
        self.target_value1.copy_weight_from(self.value1, self.tau)
        self.target_value2.copy_weight_from(self.value2, self.tau)

    def run(self):
        total_steps = 0
        self.value_function_soft_update()
        for iter in range(self.parameter.max_iter_num):
            self.global_iteration = iter
            self.policy.to(torch.device('cpu'))
            future_test = self.test_agent.submit_task(self.parameter.test_sample_num, self.policy)
            # future_ood = self.ood_agent.submit_task(self.parameter.test_sample_num, self.policy)
            # future_ns = self.non_station_agent.submit_task(self.parameter.test_sample_num, self.policy)
            self.policy.to(self.device)
            training_start = time.time()
            for step in range(self.parameter.min_batch_size):
                self.timer.register_point('sample1step')
                mem, log = self.training_agent.sample1step(self.policy, self.replay_buffer.size < self.parameter.random_num,
                                                           device=self.device)
                self.timer.register_end()
                if step % self.parameter.update_interval == 0 and self.replay_buffer.size > self.parameter.start_train_num and len(self.replay_buffer) > 1:
                    self.timer.register_point('self.update')
                    update_log = self.update()
                    self.timer.register_end()
                    log.update(update_log)
                self.replay_buffer.mem_push(mem)
                self.logger.add_tabular_data(**log)
            self.update_policy_queue()
            if not self.parameter.baseline_sac and 'QMean1' in self.logger.current_data:
                self.update_eta_r(np.mean(self.logger.current_data['QMean1']))
                self.logger.log_tabular('HedgeR', self.r)
                self.logger.log_tabular('HedgeBr', self.Br)
                self.logger.log_tabular('HedgeEtar', self.eta_r)
            total_steps += self.parameter.min_batch_size
            training_end = time.time()
            self.logger.log('start testing...')
            batch_test, log_test, mem_test = self.test_agent.query_sample(future_test, need_memory=True)
            # batch_ood, log_ood, mem_ood = self.test_agent.query_sample(future_ood, need_memory=True)
            # batch_non_station, log_non_station, mem_non_station = self.non_station_agent.query_sample(future_ns,
            #                                                                                           need_memory=True)
            testing_end = time.time()
            self.logger.add_tabular_data(**self.append_key(log_test, "Test"))
            # self.logger.add_tabular_data(**self.append_key(log_ood, "OOD"))
            # self.logger.add_tabular_data(**self.append_key(log_non_station, "NS"))
            self.logger.log_tabular('TotalInteraction', total_steps)
            # self.logger.log_tabular('OODDeltaVSTestRet', np.mean(log_ood['EpRet']) - np.mean(log_test['EpRet']))
            # self.logger.log_tabular('NSDeltaVSTestRet', np.mean(log_non_station['EpRet']) - np.mean(log_test['EpRet']))
            self.logger.log_tabular('ReplayBufferTrajNum', len(self.replay_buffer))
            self.logger.log_tabular('ReplayBufferSize', self.replay_buffer.size)
            self.logger.log_tabular('TrainingPeriod', training_end - training_start)
            self.logger.log_tabular('TestingPeriod', testing_end - training_end)
            self.logger.add_tabular_data(**self.timer.summary())
            self.save()
            self.logger.dump_tabular()

    def save(self):
        self.policy.save(self.logger.model_output_dir)
        self.value1.save(self.logger.model_output_dir, 0)
        self.value2.save(self.logger.model_output_dir, 1)
        self.target_value1.save(self.logger.model_output_dir, "target0")
        self.target_value2.save(self.logger.model_output_dir, "target1")
        torch.save(self.policy_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'policy_optim.pt'))
        torch.save(self.value_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'value_optim.pt'))
        torch.save(self.alpha_optimizer.state_dict(), os.path.join(self.logger.model_output_dir, 'alpha_optim.pt'))

    def load(self):
        self.policy.load(self.logger.model_output_dir, map_location=self.device)
        self.value1.load(self.logger.model_output_dir, 0, map_location=self.device)
        self.value2.load(self.logger.model_output_dir, 1, map_location=self.device)
        self.target_value1.load(self.logger.model_output_dir, "target0", map_location=self.device)
        self.target_value2.load(self.logger.model_output_dir, "target1", map_location=self.device)
        self.policy_optimizer.load_state_dict(torch.load(os.path.join(self.logger.model_output_dir, 'policy_optim.pt'),
                                                         map_location=self.device))
        self.value_optimizer.load_state_dict(torch.load(os.path.join(self.logger.model_output_dir, 'value_optim.pt'),
                                                        map_location=self.device))
        self.alpha_optimizer.load_state_dict(torch.load(os.path.join(self.logger.model_output_dir, 'alpha_optim.pt'),
                                                        map_location=self.device))


if __name__ == '__main__':
    import ray
    ray.init()
    sac = SAC()
    sac.run()
    #sac.save()
    #sac.load()
