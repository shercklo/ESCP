import tensorflow as tf
import gym
import os
import robosumo.envs
import numpy as np

from robosumo.policy_zoo import LSTMPolicy, MLPPolicy
from robosumo.policy_zoo.utils import load_params, set_from_flat

POLICY_FUNC = {
    "mlp": MLPPolicy,
    "lstm": LSTMPolicy,
}
class BLPolicy:
    def __init__(self, ob_space, ac_space, id=0,
                 env_name='Ant', policy_name='mlp', parameter_version=1):
        policy_zoo_asset_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'policy_zoo', 'assets')
        agent_name = env_name.lower()
        param_path = os.path.join(policy_zoo_asset_path, agent_name, policy_name,
                                  "agent-params-v%d.npy" % parameter_version)
        self.id = id
        tf_config = tf.ConfigProto(
            inter_op_parallelism_threads=1,
            intra_op_parallelism_threads=1)
        self.sess = tf.Session(config=tf_config)
        with self.sess.as_default():
            print('load model from {}'.format(param_path))
            self.policy = POLICY_FUNC[policy_name](scope='{}_{}_{}_policy'.format(env_name, policy_name, id),
                                                   reuse=tf.AUTO_REUSE,
                                                   ob_space=ob_space,
                                                   ac_space=ac_space,
                                                   hiddens=[64, 64], normalize=True)
            self.sess.run(tf.variables_initializer(tf.global_variables()))
        parameter = np.load(param_path)
        # print(parameter)
        with self.sess.as_default():
            set_from_flat(self.policy.get_variables(), parameter)

    def get_action(self, state, deterministic=True):
        with self.sess.as_default():
            return self.policy.act(state, not deterministic)[0]



def main():
    env_name = "RoboSumo-Ant-vs-Ant-v0"
    agents = [env_name.split('-')[1].lower(), env_name.split('-')[3].lower()]
    policy_zoo_asset_path = '/Users/fanmingluo/Github/robosumo/robosumo/policy_zoo/assets'
    env = gym.make(env_name)
    for agent in env.agents:
        agent._adjust_z = -0.5
    observation_spaces = env.observation_space
    action_spaces = env.action_space
    policies = [BLPolicy(ob, ac, id_, a, parameter_version=3) for a, ob, ac, id_ in zip(agents, observation_spaces, action_spaces,
                                                                                          range(len(agents)))]
    for traj in range(60):
        states = env.reset()
        while True:
            action = [policy.get_action(state) for policy, state in zip(policies, states)]
            next_states, rewards, dones, infos = env.step(action)
            # env.render(mode='human')
            if dones[0]:
                if 'winner' in infos[0]:
                    print('player1: winner: ', infos[0]['winner'])
                elif 'winner' in infos[1]:
                    print('player2: winner: ', infos[1]['winner'])
                else:
                    print('draw!!')
                break
            states = next_states


if __name__ == '__main__':
    main()