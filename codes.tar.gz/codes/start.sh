#! /bin/bash
python3 generate_tmuxp.py && tmuxp load run_all.yaml